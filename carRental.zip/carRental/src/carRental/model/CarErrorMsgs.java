package carRental.model;

public class CarErrorMsgs {
	
	private String errorMsg;
	private String carNameError;
	private String weekdayRateError;
	private String weekendRateError;
	private String weekRateError;
	private String gpsError;
	private String siriusXMError;
	private String onStarError;
	
	public CarErrorMsgs() {
		this.errorMsg = "";
		this.carNameError = "";
		this.weekdayRateError = "";
		this.weekendRateError = "";
		this.weekRateError = "";
		this.gpsError = "";
		this.siriusXMError = "";
		this.onStarError = "";
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}
	
	public void setErrorMsg(Car car) {
		
		if(!carNameError.equals("") || !weekdayRateError.equals("") || !weekendRateError.equals("") || 
				!weekRateError.equals("") || !gpsError.equals("") || siriusXMError.equals("") || onStarError.equals("")) {
			this.errorMsg = "Please correct the following errors:<br>";
			if(!carNameError.equals("")) {
				this.errorMsg = this.errorMsg + carNameError +"<br>";
			}
			if(!weekdayRateError.equals("")) {
				this.errorMsg = this.errorMsg + weekdayRateError +"<br>"; 
			}
			if(!weekendRateError.equals("")) {
				this.errorMsg = this.errorMsg + weekendRateError +"<br>";
			}
			if(!weekRateError.equals("")) {
				this.errorMsg = this.errorMsg + weekRateError +"<br>";
			}
			if(!gpsError.equals("")) {
				this.errorMsg = this.errorMsg + gpsError +"<br>";
			}
			if(!siriusXMError.equals("")) {
				this.errorMsg = this.errorMsg + siriusXMError +"<br>";
			}
			if(!onStarError.equals("")) {
				this.errorMsg = this.errorMsg + onStarError +"<br>";
			}
		}
	}

	public String getCarNameError() {
		return carNameError;
	}

	public void setCarNameError(String carNameError) {
		this.carNameError = carNameError;
	}

	public String getWeekdayRateError() {
		return weekdayRateError;
	}

	public void setWeekdayRateError(String weekdayRateError) {
		this.weekdayRateError = weekdayRateError;
	}

	public String getWeekendRateError() {
		return weekendRateError;
	}

	public void setWeekendRateError(String weekendRateError) {
		this.weekendRateError = weekendRateError;
	}

	public String getWeekRateError() {
		return weekRateError;
	}

	public void setWeekRateError(String weekRateError) {
		this.weekRateError = weekRateError;
	}

	public String getGpsError() {
		return gpsError;
	}

	public void setGpsError(String gpsError) {
		this.gpsError = gpsError;
	}

	public String getSiriusXMError() {
		return siriusXMError;
	}

	public void setSiriusXMError(String siriusXMError) {
		this.siriusXMError = siriusXMError;
	}

	public String getOnStarError() {
		return onStarError;
	}

	public void setOnStarError(String onStarError) {
		this.onStarError = onStarError;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	
}
