package carRental.model;

import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;

public class Reservations {
		private String userName;
		private String carName;
		private int noOfOccupants;
		private String startDate;
		private String endDate;
		private String startTime;
		private String endTime;
		private String GPS;
		private String onStar;
		private String siriusXM;
		
		
		public Reservations() {
			
		}
	
		public void setReservation(int occupants, String sdate, String edate, String stime, String etime) {
		
			this.noOfOccupants = occupants;
			this.startDate = sdate;
			this.endDate = edate;
			this.startTime = stime;
			this.endTime = etime;

		}
		
		public void validateReservation(Reservations reservations, requestRentalErrorMsgs errorMsgs) {
			errorMsgs.setDateError(validateDates(reservations.getStartDate(), reservations.getEndDate()));
			errorMsgs.setTimeError(validateTimes(reservations.getStartDate(), reservations.getEndDate(),reservations.getStartTime(), 
					reservations.getEndTime()));
			if(!errorMsgs.getDateError().equals("Please fill out this field") || 
					!errorMsgs.getTimeError().equals("Please fill out this field")) {
				errorMsgs.setInvalidWorkingHoursError(validateWorkingHours(reservations.getStartDate(), reservations.getEndDate(),reservations.getStartTime(), 
						reservations.getEndTime()));
				
			}
			errorMsgs.setErrorMsg();
		}

		private String validateWorkingHours(String startDate2, String endDate2, String startTime2, String endTime2) {
			String result="";
			
			Date sdate = Date.valueOf(startDate2);
			Date edate = Date.valueOf(endDate2);
			
			startTime2 += ":00";
			endTime2 += ":00";
			Time stime = Time.valueOf(startTime2);
			Time etime = Time.valueOf(endTime2);
			
			SimpleDateFormat  simpleDateformat = new SimpleDateFormat("EEEE"); // the day of the week spelled out completely
	        
	        if(simpleDateformat.format(sdate).equalsIgnoreCase("Monday") || simpleDateformat.format(sdate).equalsIgnoreCase("Tuesday") || 
	        		simpleDateformat.format(sdate).equalsIgnoreCase("Wednesday") || simpleDateformat.format(sdate).equalsIgnoreCase("Thursday") ||
	        		simpleDateformat.format(sdate).equalsIgnoreCase("Friday")) {
	        	if(sdate.compareTo(edate) == 0) {	        		
	        		if((stime.after(Time.valueOf("19:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("09:00:00")) || etime.after(Time.valueOf("20:00:00")))){
	        			result = "Weekday 8am-8pm";
	        		}
	        	}
	        	else if((sdate.compareTo(edate) != 0) && (!simpleDateformat.format(edate).equalsIgnoreCase("Saturday") &&
	        			(!simpleDateformat.format(edate).equalsIgnoreCase("Sunday")))) {
	        		if((stime.after(Time.valueOf("20:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("08:00:00")) || etime.after(Time.valueOf("20:00:00")))){
	        			result = "Weekday 8am-8pm";
	        		}
	        	}
	        	else if((sdate.compareTo(edate) != 0) && (simpleDateformat.format(edate).equalsIgnoreCase("Saturday"))) {
	        		if((stime.after(Time.valueOf("20:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("08:00:00")) || etime.after(Time.valueOf("17:00:00")))){
	        			result = "Weekday 8am-8pm and Saturday 08am-5pm";
	        		}
	        	}
	        	else {
	        		if((stime.after(Time.valueOf("20:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("12:00:00")) || etime.after(Time.valueOf("17:00:00")))){
	        			result = "Weekday 8am-8pm and Sunday 12pm-5pm";
	        		}
	        	}
	        }
	        else if(simpleDateformat.format(sdate).equalsIgnoreCase("Saturday")) {
	        	if(sdate.compareTo(edate)==0){
	        		if((stime.after(Time.valueOf("16:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("09:00:00")) || etime.after(Time.valueOf("17:00:00")))){
	        			result = "Saturday 8am-5pm";
	        		}
	        	}
	        	else if((sdate.compareTo(edate)!=0) && (simpleDateformat.format(edate).equalsIgnoreCase("Saturday"))){
	        		if((stime.after(Time.valueOf("17:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("08:00:00")) || etime.after(Time.valueOf("17:00:00")))){
	        			result = "Saturday 8am-5pm";
	        		}
	        	}
	        	else if((sdate.compareTo(edate) != 0)  && (simpleDateformat.format(edate).equalsIgnoreCase("Sunday"))){
	        		if((stime.after(Time.valueOf("17:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("12:00:00")) || etime.after(Time.valueOf("17:00:00")))){
	        			result = "Saturday 8am-5pm and Sunday 12pm-5pm";
	        		}
	        	}
	        	else if((sdate.compareTo(edate) != 0)  && (!simpleDateformat.format(edate).equalsIgnoreCase("Sunday")) 
	        			&& (!simpleDateformat.format(edate).equalsIgnoreCase("Saturday"))) { 
	        		if((stime.after(Time.valueOf("17:00:00")) || stime.before(Time.valueOf("08:00:00"))) || 
	        				(etime.before(Time.valueOf("08:00:00")) || etime.after(Time.valueOf("20:00:00")))){
	        			result = "Saturday 8am-5pm and Weekday 8am-8pm";
	        		}
	        	}
	        }
	        else if(simpleDateformat.format(sdate).equalsIgnoreCase("Sunday")) {
	        	
	        	if(sdate.compareTo(edate)==0){
	        		
	        		if((stime.after(Time.valueOf("16:00:00")) || stime.before(Time.valueOf("12:00:00"))) || 
	        				(etime.before(Time.valueOf("13:00:00")) || etime.after(Time.valueOf("17:00:00")))){
	        			result = "Sunday 12pm-5pm";
	        		}
	        	}
	        		
	        	else if((sdate.compareTo(edate)!=0) && ((simpleDateformat.format(edate).equalsIgnoreCase("Saturday")))){
	        		
		        		if((stime.after(Time.valueOf("17:00:00")) || stime.before(Time.valueOf("12:00:00"))) || 
		        				(etime.before(Time.valueOf("08:00:00")) || etime.after(Time.valueOf("17:00:00")))){
		        			result = "Sunday 12pm-5 pm and Saturday 8am-5pm";
		        		}	
	        		}
	        	
	        	else if((sdate.compareTo(edate)!=0) && ((simpleDateformat.format(edate).equalsIgnoreCase("Sunday")))){
	        		
	        		if((stime.after(Time.valueOf("17:00:00")) || stime.before(Time.valueOf("12:00:00"))) || 
	        				(etime.before(Time.valueOf("12:00:00")) || etime.after(Time.valueOf("17:00:00")))){
	        			result = "Sunday 12pm-5pm";
	        		}
	        	}
	        	else if((sdate.compareTo(edate) != 0)  && (!simpleDateformat.format(edate).equalsIgnoreCase("Sunday")) 
		        		&& (!simpleDateformat.format(edate).equalsIgnoreCase("Saturday"))){
	        		
		        	if((stime.after(Time.valueOf("17:00:00")) || stime.before(Time.valueOf("12:00:00"))) || 
		        			(etime.before(Time.valueOf("08:00:00")) || etime.after(Time.valueOf("20:00:00")))){
		        		result = "Sunday 12pm-5pm and Weekday 8am-8pm";
		        		}
	        		}    
	        }
			return result;
		}

		private String validateTimes(String startDate2, String endDate2, String startTime2, String endTime2) {
			String result = "";
			if(startTime2.equals("") || endTime2.equals("")) {
				result = "Please fill out this field";
			}
			else {
				Date sdate = Date.valueOf(startDate2);
				Date edate = Date.valueOf(endDate2);
				System.out.println(sdate);
				System.out.println(edate);
				startTime2 += ":00";
				endTime2 += ":00";
				Time stime = Time.valueOf(startTime2);
				Time etime = Time.valueOf(endTime2);
				
				if(sdate.compareTo(edate) == 0) {
					if(stime.after(etime) || stime.compareTo(etime) == 0) {
						result = "Start time should be before end time";
					}
				}
			}
			
			return result;
		}

		private String validateDates(String startDate2, String endDate2) {
			String result = "";
			if(startDate2.equals("") || endDate2.equals("")) {
				result = "Please fill out this field";
			}
			else {
				Date sdate = Date.valueOf(startDate2);
				Date edate = Date.valueOf(endDate2);
				if(sdate.after(edate)) {
					result = "Start date should be before end date";
				}
			
			}
				return result;
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public String getCarName() {
			return carName;
		}

		public void setCarName(String carName) {
			this.carName = carName;
		}

		public int getNoOfOccupants() {
			return noOfOccupants;
		}

		public void setNoOfOccupants(int noOfOccupants) {
			this.noOfOccupants = noOfOccupants;
		}

		public String getStartDate() {
			return startDate;
		}

		public void setStartDate(String startDate) {
			this.startDate = startDate;
		}

		public String getEndDate() {
			return endDate;
		}

		public void setEndDate(String endDate) {
			this.endDate = endDate;
		}

		public String getStartTime() {
			return startTime;
		}

		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}

		public String getEndTime() {
			return endTime;
		}

		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}

		public String getGPS() {
			return GPS;
		}

		public void setGPS(String gPS) {
			GPS = gPS;
		}

		public String getOnStar() {
			return onStar;
		}

		public void setOnStar(String onStar) {
			this.onStar = onStar;
		}

		public String getSiriusXM() {
			return siriusXM;
		}

		public void setSiriusXM(String siriusXM) {
			this.siriusXM = siriusXM;
		}
		
		
}
