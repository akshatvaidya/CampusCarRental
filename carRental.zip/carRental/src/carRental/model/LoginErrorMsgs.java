package carRental.model;

public class LoginErrorMsgs {
	private String errorMsg;
	private String usernameError;
	private String passwordError;
	
	public LoginErrorMsgs() {
		this.errorMsg = "";
		this.usernameError = "";
		this.passwordError = "";
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}
	
	public void setErrorMsg(String username2, String password2) {
		if(!usernameError.equals("") || !passwordError.equals("")) {
			this.errorMsg = "Please correct the following errors";
			if(!usernameError.equals("")) {
				this.errorMsg = this.errorMsg + usernameError +"<br>";
			}
			if(!passwordError.equals("")) {
				this.errorMsg = this.errorMsg +  passwordError +"<br";
			}
		}
	}

	public String getUsernameError() {
		return usernameError;
	}

	public void setUsernameError(String usernameError) {
		this.usernameError = usernameError;
	}

	public String getPasswordError() {
		return passwordError;
	}

	public void setPasswordError(String passwordError) {
		this.passwordError = passwordError;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	
}
