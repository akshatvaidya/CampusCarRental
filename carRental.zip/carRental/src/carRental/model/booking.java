package carRental.model;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import carRental.data.CarDAO;

public class booking {

	@SuppressWarnings("rawtypes")
	public double calculateInvoice(String selectedCar, Reservations reservation, double extrasCost, boolean member) {

		double totalCost = 0.0d;

		LocalDate date1 = LocalDate.parse(reservation.getStartDate());
		LocalDate date2 = LocalDate.parse(reservation.getEndDate());
	
		
		SimpleDateFormat  simpleDateformat = new SimpleDateFormat("EEEE"); 
		Period period = Period.between(date1, date2);
		int weeks = (period.getDays() +1) / 7;
		int remainingDays = (period.getDays() + 1) % 7;
		
		
		ArrayList<String> carDetails = new ArrayList<String>();
		carDetails = CarDAO.getCarDetails(selectedCar);
		
		totalCost += weeks * Double.parseDouble(carDetails.get(4));
		
		//LocalDate date3 = date2.minusDays(5);
		
		HashMap<LocalDate, String> remaining = new HashMap<LocalDate, String>();
		for(int i = remainingDays; i > 0; i--) {
			LocalDate date = date2.minusDays(i-1);
			Date d = Date.valueOf(date);
			String day = simpleDateformat.format(d);
			remaining.put(date, day);
		}

		Set set = remaining.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) {
			 HashMap.Entry mentry = (HashMap.Entry)iterator.next();
	        /* System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
	         System.out.println(mentry.getValue());*/
			 
			 if(mentry.getValue().equals("Monday") || mentry.getValue().equals("Tuesday") || mentry.getValue().equals("Wednesday") ||
					 mentry.getValue().equals("Thursday") || mentry.getValue().equals("Friday")) {
				 totalCost += Double.parseDouble(carDetails.get(2));
			 }
			 else if(mentry.getValue().equals("Saturday") || mentry.getValue().equals("Sunday")) {
				 totalCost += Double.parseDouble(carDetails.get(3));
			 }
		}
		totalCost += extrasCost;
		System.out.println(totalCost);
		totalCost = totalCost + (8.25/100 * totalCost);
		System.out.println(totalCost);
		if(member == true) {
			totalCost = totalCost * 0.9d;
		}
		return totalCost;
	}

}
