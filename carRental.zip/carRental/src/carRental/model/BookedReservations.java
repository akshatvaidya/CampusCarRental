package carRental.model;

public class BookedReservations {
	int reservationID;
	String username;
	String carSelected;
	int noOfOccupants;
	String startDate;
	String endDate;
	String startTime;
	String endTime;
	String gps;
	String onstar;
	String siriusxm;
	double cost;
	
	public void setReservation(String username, String carSelected, int noOfOccupants, String startDate,
			String endDate, String startTime, String endTime, String g, String o, String s, double totalCost) {
		this.username = username;
		this.carSelected = carSelected;
		this.noOfOccupants = noOfOccupants;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.gps = g;
		this.onstar = o;
		this.siriusxm = s;
		this.cost = totalCost;
	}

	public BookedReservations() {
		username="";	
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCarSelected() {
		return carSelected;
	}

	public void setCarSelected(String carSelected) {
		this.carSelected = carSelected;
	}

	public int getNoOfOccupants() {
		return noOfOccupants;
	}

	public void setNoOfOccupants(int noOfOccupants) {
		this.noOfOccupants = noOfOccupants;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getGps() {
		return gps;
	}

	public void setGps(String gps) {
		this.gps = gps;
	}

	public String getOnstar() {
		return onstar;
	}

	public void setOnstar(String onstar) {
		this.onstar = onstar;
	}

	public String getSiriusxm() {
		return siriusxm;
	}

	public void setSiriusxm(String siriusxm) {
		this.siriusxm = siriusxm;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public int getReservationID() {
		return reservationID;
	}

	public void setReservationID(int reservationID) {
		this.reservationID = reservationID;
	}

	
	

}
