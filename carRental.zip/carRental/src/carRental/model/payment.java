package carRental.model;

import java.sql.Date;

public class payment {
		
	private String nameOnCard;
	private String cardNumber;
	private String expiryDate;
	private String cvv;
	private String cardType;

	public payment() { 

	}

	public void setPayment(String nameOnCard2, String cardType2, String cardNumber2, String expiry,
			String cvv2) {
		this.nameOnCard = nameOnCard2;
		this.cardNumber = cardNumber2;
		this.cardType = cardType2;
		this.expiryDate = expiry;
		this.cvv = cvv2;
		
	}
	
	public void validatePayment(makePaymentErrorMsgs errorMsgs, String errorMsg) {
		errorMsgs.setNameError(validateNameError(this.getNameOnCard()));
		errorMsgs.setCardNumberError(validateCardNumberError(this.getCardNumber(), this.getCardType()));
		errorMsgs.setDateError(validateDateError(this.getExpiryDate()));
		errorMsgs.setCvvError(validateCvvError(this.getCvv(), this.getCardType()));
		errorMsgs.setErrorMsg(errorMsg);
		
	}
	
	private String validateCvvError(String cvv2, String cardType) {
			String result="";
			
			if(cardType.equalsIgnoreCase("visa") || cardType.equalsIgnoreCase("mastercard")) {
				if(cvv.length() != 3) {
					result = "CVV number should be 3 digit long";
				}
				if(!cvv2.matches("[0-9]{1,}")) {
					result = "CVV number can only contain numbers";
				}
			}
			else {
				if(cvv.length() != 4) {
					result = "American Express Cards should have a 4 digit CVV number";
				}
				if(!cvv2.matches("[0-9]{1,}")) {
					result = "CVV number can only contain numbers";
				}
			}
		return result;
	}

	private String validateDateError(String expiryDate2) {
		String result="";
		long millis=System.currentTimeMillis();  
		java.sql.Date date2=new java.sql.Date(millis);
		try {
			Date l = Date.valueOf(expiryDate2);
			if(date2.after(l)) {
				result = "Credit Card should not be expired";
			}
		}
		catch(Exception e) {
			result = "Please enter a valid date";
		}
		return result;
	}

	private String validateCardNumberError(String cardNumber2, String cardType) {
		String result="";
		
		if(cardType.equalsIgnoreCase("visa")) {
			if(!cardNumber2.startsWith("4")) {
				result = "Visa card number should start with a 4";
			}
			else if(cardNumber2.length() != 16) {
				result = "Visa Card number should be 16 digits long";
			}
		}
		else if(cardType.equalsIgnoreCase("american")) {
			if(cardNumber2.length() != 15) {
				result = "American Express Card number should be 15 digits long";
			}
			else if(!cardNumber2.startsWith("37")) {
				result = "American Express card number should start with 37";
			}
		}
		else if(cardType.equalsIgnoreCase("mastercard")) {
			if(cardNumber2.length() != 16) {
				result = "Mastercard Card number should be 16 digits long";
			}
		}

		return result;

	}

	private String validateNameError(String nameOnCard2) {
		String result="";
		System.out.println(nameOnCard2);
		if(nameOnCard2.length() < 3 || nameOnCard2.length() > 45) {
			result = "Name on the card must be between 3 to 45 characters";
		}
		else if(!nameOnCard2.matches("^[\\p{L} .'-]+$")) {
				result = "Name on the card can only contain letters";
			}
		return result;
	}

	public String getNameOnCard() {
		return nameOnCard;
	}



	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}



	public String getCardNumber() {
		return cardNumber;
	}



	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}



	public String getExpiryDate() {
		return expiryDate;
	}



	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}



	public String getCvv() {
		return cvv;
	}



	public void setCvv(String cvv) {
		this.cvv = cvv;
	}



	public String getCardType() {
		return cardType;
	}



	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

}
