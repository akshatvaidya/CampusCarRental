package carRental.model;

public class requestRentalErrorMsgs {
		private String errorMsg;
		private String dateError;
		private String timeError;
		private String reservationError;
		private String invalidWorkingHoursError;
		
		public requestRentalErrorMsgs() {
			this.errorMsg = "";
			this.dateError = "";
			this.timeError = "";
			this.reservationError="";
			this.invalidWorkingHoursError="";
		}
		
		public String getErrorMsg() {
			return errorMsg;
		}
		
		public void setErrorMsg() {
			if(!invalidWorkingHoursError.equals("")) {
				this.errorMsg = "Requested hours are outside of the working hours";
			}
			else if(!dateError.equals("") || !timeError.equals("")) {
				this.errorMsg = "Please correct the following errors";
				if(!dateError.equals("")) {
					this.errorMsg = this.errorMsg + dateError +"<br>";
				}
				if(!timeError.equals("")) {
					this.errorMsg = this.errorMsg +  timeError +"<br";
				}
			}
			else if(!reservationError.equals("")) {
				this.errorMsg = reservationError;
			}
		}

		public String getDateError() {
			return dateError;
		}

		public void setDateError(String dateError) {
			this.dateError = dateError;
		}

		public String getTimeError() {
			return timeError;
		}

		public void setTimeError(String timeError) {
			this.timeError = timeError;
		}

		public void setErrorMsg(String errorMsg) {
			this.errorMsg = errorMsg;
		}

		public String getReservationError() {
			return reservationError;
		}

		public void setReservationError(String reservationError) {
			this.reservationError = reservationError;
		}

		public void setInvalidWorkingHoursError(String validateWorkingHoursError) {
			this.invalidWorkingHoursError = validateWorkingHoursError;
			
		}

		public String getInvalidWorkingHoursError() {
			return invalidWorkingHoursError;
		}
		
		
		

}
