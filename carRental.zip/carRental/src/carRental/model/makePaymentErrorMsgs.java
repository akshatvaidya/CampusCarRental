package carRental.model;

public class makePaymentErrorMsgs {
		
	private String nameError;
	private String cardNumberError;
	private String dateError;
	private String cvvError;
	private String errorMsg;
	
	public makePaymentErrorMsgs() {
		this.errorMsg="";
		this.nameError="";
		this.cardNumberError="";
		this.dateError="";
		this.cvvError="";
	}

	public void setErrorMsg(String errorMsg) {
		if(!nameError.equals("") || !cardNumberError.equals("") || !dateError.equals("") || !cvvError.equals("")) {
			this.errorMsg = "Please correct the following errors";
			if(!nameError.equals("")) {
				this.errorMsg = errorMsg + nameError + "<br>";
			}
			if(!cardNumberError.equals("")) {
				this.errorMsg = errorMsg + cardNumberError + "<br>";
			}
			if(!dateError.equals("")) {
				this.errorMsg = errorMsg + dateError + "<br>";
			}
			if(!cvvError.equals("")) { 
				this.errorMsg = errorMsg + cvvError + "<br>";
			}
		}
	}
	
	public String getNameError() {
		return nameError;
	}

	public void setNameError(String nameError) {
		this.nameError = nameError;
	}

	public String getCardNumberError() {
		return cardNumberError;
	}

	public void setCardNumberError(String cardNumberError) {
		this.cardNumberError = cardNumberError;
	}

	public String getDateError() {
		return dateError;
	}

	public void setDateError(String dateError) {
		this.dateError = dateError;
	}

	public String getCvvError() {
		return cvvError;
	}

	public void setCvvError(String cvvError) {
		this.cvvError = cvvError;
	}

	public String getErrorMsg() {
		return errorMsg;
	}
	
}
