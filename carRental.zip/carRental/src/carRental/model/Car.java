package carRental.model;

import java.io.Serializable;

import carRental.data.CarDAO;

@SuppressWarnings("serial")
public class Car implements Serializable {
	private String carName;
	private String capacity;
	private String weekdayRate;
	private String weekendRate;
	private String weekRate;
	private String gps;
	private String siriusXM;
	private String onStar;
	
	public void setCar(String carName, String capacity, String weekdayRate, String weekendRate, String weekRate,
			String gps, String siriusXM, String onStar) {
		this.carName = carName;
		this.capacity = capacity;
		this.weekdayRate = weekdayRate;
		this.weekendRate = weekendRate;
		this.weekRate = weekRate;
		this.gps = gps;
		this.siriusXM = siriusXM;
		this.onStar = onStar;
	}
	
	public void validateCar(Car car, AddCarErrorMsgs errorMsgs) {
		errorMsgs.setNameError(validateCarNameCar(car.getCarName()));
		errorMsgs.setWeekDayRateError(validateRate(car.getWeekdayRate()));
		errorMsgs.setWeekendRateError(validateRate(car.getWeekendRate()));
		errorMsgs.setWeekRateError(validateRate(car.getWeekRate()));
		errorMsgs.setGpsRateError(validateRate(car.getGps()));
		errorMsgs.setOnStarRateError(validateRate(car.getOnStar()));
		errorMsgs.setSiriusXMRateError(validateRate(car.getSiriusXM()));
		errorMsgs.setErrorMsg(car);
	}

	private String validateRate(String Rate) {
		String result = "";

		if(!Rate.matches("[0-9]{1,}(\\.[0-9]*)?")) {
			result = "Rate can only be a number";
		}
		return result;
	}

	private String validateCarNameCar(String carName2) {
		String result = "";
		if(carName2.length() < 3 || carName2.length() > 45) {
			result = "Car name must be between 3 to 45 characters";
		}
		else if(!carName2.matches("[a-z,A-Z]{1,}")) {
			result = "Car name must only contain letters";
		}
		else if(!CarDAO.getCarDetails(carName2).isEmpty()){
			result = "Car name already present";
		}
		return result;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getWeekdayRate() {
		return weekdayRate;
	}

	public void setWeekdayRate(String weekdayRate) {
		this.weekdayRate = weekdayRate;
	}

	public String getWeekendRate() {
		return weekendRate;
	}

	public void setWeekendRate(String weekendRate) {
		this.weekendRate = weekendRate;
	}

	public String getWeekRate() {
		return weekRate;
	}

	public void setWeekRate(String weekRate) {
		this.weekRate = weekRate;
	}

	public String getGps() {
		return gps;
	}

	public void setGps(String gps) {
		this.gps = gps;
	}

	public String getSiriusXM() {
		return siriusXM;
	}

	public void setSiriusXM(String siriusXM) {
		this.siriusXM = siriusXM;
	}

	public String getOnStar() {
		return onStar;
	}

	public void setOnStar(String onStar) {
		this.onStar = onStar;
	} 

/*	public Car(String carName, int capacity, double weekdayRate, double weekendRate, double weekRate, double gps,
			double siriusXM, double onStar) {
		this.carName = carName;
		this.capacity = capacity;
		this.weekdayRate = weekdayRate;
		this.weekendRate = weekendRate;
		this.weekRate = weekRate;
		this.gps = gps;
		this.siriusXM = siriusXM;
		this.onStar = onStar;
	}*/
}
