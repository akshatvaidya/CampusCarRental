package carRental.model;
import java.io.Serializable;
import java.sql.Date;

import carRental.data.SystemUserDAO;


@SuppressWarnings("serial")
public class SystemUser implements Serializable {
	
	private String username;
	private String password;
	private String role;
	private String UTAID;
	private String firstname;
	private String lastname;
	private String addressline1;
	private String addressline2;
	private String city;
	private String state;
	private String country;
	private String zipcode;
	private String drivinglicense;
	private String licenseexpiry;
	private String issuingcountry;
	private String AACMember;
	private String email;
	private String dateofbirth;
	private String contact;

	
	public void setSystemUser (String username, String password, String role, String utaid, String firstname, String lastname,
			String addressline1, String addressline2, String city, String state, String country, String zipcode, String drivinglicense,
			String licenseexpiry, String issuingcountry, String AACMember, String email, String dateofbirth, String contact) {
		this.username = username;
		this.password = password;
		this.role = role;
		this.UTAID = utaid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.addressline1 = addressline1;
		this.addressline2 = addressline2;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zipcode = zipcode;
		this.drivinglicense = drivinglicense;
		this.licenseexpiry = licenseexpiry;
		this.issuingcountry = issuingcountry;
		this.AACMember = AACMember;
		this.email = email;
		this.dateofbirth = dateofbirth;
		this.contact = contact;
	}
	
	public void validateSystemUser (SystemUser systemuser, SystemUserErrorMsgs errorMsgs)
	{
			errorMsgs.setUsernameError(validateUsernameSystemUser(systemuser.getUsername())); 
			errorMsgs.setPasswordError(validatePasswordSystemUser(systemuser.getPassword(), systemuser.getUsername()));
			//errorMsgs.setRoleError(validateRole(systemuser.getRole()));
			errorMsgs.setUTAIDError(validateUTAIDSystemUser(systemuser.getUTAID())); 
			errorMsgs.setFirstnameError(validateFirstnameSystemUser(systemuser.getFirstname()));
			errorMsgs.setLastnameError(validateLastnameSystemUser(systemuser.getLastname()));
			errorMsgs.setAddressline1Error(validateAddressline1SystemUser(systemuser.getAddressline1()));
			if(systemuser.getAddressline2().length() != 0) {
				errorMsgs.setAddressline2Error(validateAddressline2SystemUser(systemuser.getAddressline2()));
			}		
			errorMsgs.setCityError(validateCitySystemUser(systemuser.getCity()));
			errorMsgs.setStateError(validateStateSystemUser(systemuser.getState()));
			errorMsgs.setCountryError(validateCountrySystemUser(systemuser.getCountry()));
			errorMsgs.setZipcodeError(validateZipcodeSystemUser(systemuser.getZipcode()));
			errorMsgs.setDrivinglicenseError(validateDrivingLicenseSystemUser(systemuser.getDrivinglicense()));
			errorMsgs.setLicenseexpiryError(validateLicenseexpirySystemUser(systemuser.getLicenseexpiry()));
			errorMsgs.setIssuingcountryError(validateIssuingCountrySystemUser(systemuser.getIssuingcountry()));
			//errorMsgs.setAACmemberError(validateAACmemberSystemUser(systemuser.getAACMember()));
			errorMsgs.setEmailError(validateEmailSystemUser(systemuser.getEmail()));
			errorMsgs.setDateofbirthError(validateDateofbirthSystemUser(systemuser.getDateofbirth()));
			errorMsgs.setContactError(validateContactSystemUser(systemuser.getContact()));
			errorMsgs.setErrorMsg(systemuser); 
					
		}
	
	public void validateUpdatingSystemUser (SystemUserErrorMsgs errorMsgs)
	{
		errorMsgs.setUsernameError(validateUpdatingUsernameSystemUser(this.getUsername())); 
			errorMsgs.setPasswordError(validatePasswordSystemUser(this.getPassword(), this.getUsername()));
			//errorMsgs.setRoleError(validateRole(systemuser.getRole()));
			errorMsgs.setUTAIDError(validateUTAIDSystemUser(this.getUTAID())); 
			errorMsgs.setFirstnameError(validateFirstnameSystemUser(this.getFirstname()));
			errorMsgs.setLastnameError(validateLastnameSystemUser(this.getLastname()));
			errorMsgs.setAddressline1Error(validateAddressline1SystemUser(this.getAddressline1()));
			if(this.getAddressline2().length() != 0) {
				errorMsgs.setAddressline2Error(validateAddressline2SystemUser(this.getAddressline2()));
			}		
			errorMsgs.setCityError(validateCitySystemUser(this.getCity()));
			errorMsgs.setStateError(validateStateSystemUser(this.getState()));
			errorMsgs.setCountryError(validateCountrySystemUser(this.getCountry()));
			errorMsgs.setZipcodeError(validateZipcodeSystemUser(this.getZipcode()));
			errorMsgs.setDrivinglicenseError(validateDrivingLicenseSystemUser(this.getDrivinglicense()));
			errorMsgs.setLicenseexpiryError(validateLicenseexpirySystemUser(this.getLicenseexpiry()));
			errorMsgs.setIssuingcountryError(validateIssuingCountrySystemUser(this.getIssuingcountry()));
			//errorMsgs.setAACmemberError(validateAACmemberSystemUser(systemuser.getAACMember()));
			errorMsgs.setEmailError(validateEmailSystemUser(this.getEmail()));
			errorMsgs.setDateofbirthError(validateDateofbirthSystemUser(this.getDateofbirth()));
			errorMsgs.setContactError(validateContactSystemUser(this.getContact()));
			errorMsgs.setErrorMsg(this);
					
		}


	private String validateUsernameSystemUser(String username2) {
		String result="";
		if(username2.length() < 3 || username2.length() > 45) {
			result = "Your username must be between 3 to 45 characters";
		}
		else if(SystemUserDAO.uniqueUsername(username2)) {
				result = "This Username is already in the database";
			}
		else if(username.matches(".*[!@#$%^&*]{1,}.*")) {
			result = "Username can only contain letters and numbers";
		}
		return result;
	}
	
	private String validateUpdatingUsernameSystemUser(String username2) {
		String result="";
		if(username2.length() < 3 || username2.length() > 45) {
			result = "Your username must be between 3 to 45 characters";
		}
		else if(username.matches(".*[!@#$%^&*]{1,}.*")) {
			result = "Username can only contain letters and numbers";
		}
		return result;
	}

	private String validatePasswordSystemUser(String password2, String username2) {
		
		String result="";
	
		if(password2.length() < 8 || password2.length() > 20) {
			result = "Your password must be between 8 to 20 characters";
		}
		else if(password2.equalsIgnoreCase(username2)) {

				result = "Your username and password cannot be the same";
		}
		else if(password2.matches(".*[0-9]{1,}.*") && password2.matches(".*[a-z]{1,}.*")
				&& password2.matches(".*[A-Z]{1,}.*") && password2.matches(".*[@#!$]{1,}.*")) {
			
		}
		else{
			result = "Password must contain an uppercase letter<br>Password must contain a number"
					+ "<br>Password must contain a special character";

		}
		return result;
	}
	
	private String validateUTAIDSystemUser(String utaid2) {

		String result="";
		if(utaid2.length() != 10) {
			result = "UTA ID must be of 10 digits only";
		}
		else if(!utaid2.matches("[0-9]{1,}")) {
			result = "UTA ID can only contain numbers";
		}
		return result;
	}
	
	private String validateFirstnameSystemUser(String firstname2) {
		String result="";
		
		if(firstname2.length() < 2 || firstname2.length() > 45) {
			result = "Your first name must be between 2 to 45 characters";
		}
		else if(!firstname2.matches("[a-z,A-Z]{1,}")) {
			result = "First name must only contain letters";
		}
		
		return result;
	}

	private String validateLastnameSystemUser(String lastname2) {
		String result="";
		
		if(lastname2.length() < 2 || lastname2.length() > 45) {
			result = "Your last name must be between 2 to 45 characters";
		}
		if(!lastname2.matches("[a-z,A-Z]{1,}")) {
			result = "Last name must only contain letters";
		}
		return result;
	}

	private String validateAddressline1SystemUser(String addressline1) {
		String result="";

		if(addressline1.length() < 3 || addressline1.length() > 45) {
			result = "Only 3 to 45 characters allowed";
		}
		else if(!addressline1.matches(".*[A-Z,a-z]{1,}.*") || !addressline1.matches(".*[0-9]{1,}.*")) {
			result = "Address must contain letters and numbers both";
		}
		return result;
	}
	
	private String validateAddressline2SystemUser(String addressline2) {
		String result="";
	
		if(addressline2.length() < 3 || addressline2.length() > 45) {
			result = "Only 3 to 45 characters allowed";
		}
		else if(!addressline2.matches(".*[A-Z,a-z]{1,}.*") || !addressline2.matches(".*[0-9]{1,}.*")) {
			result = "Address must contain letters and numbers both";
		}
		return result;
	}
	
	private String validateCitySystemUser(String city2) {
		String result="";

		if(city2.length() < 4 || city2.length() > 45) {
			result = "City can only be 4 to 45 characters long";
		}
		else if(!city2.matches("[A-Z,a-z]{1,}")) {
			result = "City can only contain letters";
		}
		return result;
	}
	
	private String validateStateSystemUser(String state2) {
		String result="";
		
		if(state2.length() < 4 || state2.length() > 45) {
			result = "State can only be 4 to 45 characters long";
		}
		else if(!state2.matches("[A-Z,a-z]{1,}")) {
			result = "State can only contain letters";
		}
		return result;
	}
	
	private String validateCountrySystemUser(String country2) {
		String result="";

		if(country2.length() < 4 || country2.length() > 45) {
			result = "Country can only be 4 to 45 characters long";
		}
		else if(!country2.matches("^[\\p{L} .'-]+$")) {
			
			result = "Country can only contain letters";
		}
		return result;
	}
	
	private String validateZipcodeSystemUser(String zipcode2) {
		String result="";
		
		if(zipcode2.length() != 5) {
			result = "Zipcode can only be 5 characters long";
		}
		else if(!zipcode2.toString().matches("[0-9]{1,}")) {
			result = "Zipcode can only contain numbers";
		}
		return result;
	}
	
	private String validateDrivingLicenseSystemUser(String drivinglicense2) {
		String result="";
		
		if(drivinglicense2.length() < 8 || drivinglicense2.length() > 20) {
			result = "License can only be 8 to 20 characters long";
		}
		else if(!drivinglicense2.matches(".*[A-Z,a-z]{1,}.*") || !drivinglicense2.matches(".*[0-9]{1,}.*")) {
			result = "License number must contain letters and numbers both";
		}
		return result;
	}
	
	private String validateLicenseexpirySystemUser(String licenseexpiry2) {
		String result="";
		
		long millis=System.currentTimeMillis();  
		java.sql.Date date=new java.sql.Date(millis);
		try {
			Date l = Date.valueOf(licenseexpiry2);
			if(date.after(l)) {
				result = "Driving License should not be expired";
			}
		}
		catch(Exception e) {
			result = "Please enter a valid date";
		}	
		return result;
	}
	
	private String validateIssuingCountrySystemUser(String issuingcountry2) {
		String result="";

		if(issuingcountry2.length() < 4 || issuingcountry2.length() > 45) {
			result = "Issuing country name can only be 4 to 45 characters long";
		}
		else if(!issuingcountry2.matches("^[\\p{L} .'-]+$")) {
			result = "Country can only contain letters";
		}
		return result;
	}
	
	private String validateEmailSystemUser(String email2) {

		String result="";

		if(email2.length() < 7 || email2.length() > 45) {
			result = "Your email ID must be between 7 to 45 characters";
		}
		else if(!email2.matches("^[^@]*@[^@]*$")) {
			result = "Email must contain only a single @ character";
		}
		else {
			try {
				String[] extensions = {"com", "gov", "net", "org", "edu", "mil"};
				String[] emailEnd = email2.split("@");
				String[] ext = emailEnd[1].split("\\.");
				
				boolean flag = true;
				for(int i = 0; i < extensions.length; i++) {
					if(!extensions[i].equals(ext[1])) {
						flag = false;
					}
					else {
						flag = true;
						break;
					}
				}
					if(flag == false) {
						result = result + "<br>Check email extension";
					}
			}
			catch(Exception e) {
				result = "Please enter a valid email address";
			}		
		}
		return result;
	}

	private String validateDateofbirthSystemUser(String dateofbirth2) {
		String result="";
		long millis=System.currentTimeMillis();  
		java.sql.Date date=new java.sql.Date(millis);
		try {
			Date d = Date.valueOf(dateofbirth2);
			if(date.before(d)) {
				result = "Date of birth cannot be greater than today's date";
			}
		}
		catch(Exception e) {
			result = "Please enter a valid date";
		}
		return result;
	}

	private String validateContactSystemUser(String contact2) {
		String result="";

		if(contact2.length() != 10) {
			result = "Contact Number must be of 10 digits only";
		}
		else if(!contact2.matches("[0-9]{1,}")) {
			result = "Contact number can only contain numbers";
		}
		return result;
	}
	
	
	//Getters and setters
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUTAID() {
		return UTAID;
	}
	public void setUTAID(String uTAID) {
		UTAID = uTAID;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAddressline1() {
		return addressline1;
	}
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}
	public String getAddressline2() {
		return addressline2;
	}
	public void setAddressline2(String addressline2) {
		this.addressline2 = addressline2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getDrivinglicense() {
		return drivinglicense;
	}
	public void setDrivinglicense(String drivinglicense) {
		this.drivinglicense = drivinglicense;
	}
	public String getLicenseexpiry() {
		return licenseexpiry;
	}
	public void setLicenseexpiry(String licenseexpiry) {
		this.licenseexpiry = licenseexpiry;
	}
	public String getIssuingcountry() {
		return issuingcountry;
	}
	public void setIssuingcountry(String issuingcountry) {
		this.issuingcountry = issuingcountry;
	}
	public String getAACMember() {
		return AACMember;
	}
	public void setAACMember(String aACMember) {
		AACMember = aACMember;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
}
