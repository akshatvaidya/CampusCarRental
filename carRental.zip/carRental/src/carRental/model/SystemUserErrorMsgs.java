package carRental.model;

public class SystemUserErrorMsgs {
	private String errorMsg;
	private String usernameError;
	private String passwordError;
	private String roleError;
	private String UTAIDError;
	private String firstnameError;
	private String lastnameError;
	private String addressline1Error;
	private String addressline2Error;
	private String cityError;
	private String stateError;
	private String countryError;
	private String zipcodeError;
	private String drivinglicenseError;
	private String licenseexpiryError;
	private String issuingcountryError;
	private String AACmemberError;
	private String emailError;
	private String dateofbirthError;
	private String contactError;
	
	
	public SystemUserErrorMsgs() {
		this.errorMsg="";
		this.usernameError="";
		this.passwordError="";
		this.roleError="";
		this.UTAIDError="";
		this.firstnameError="";
		this.lastnameError="";
		this.addressline1Error="";
		this.addressline2Error="";
		this.cityError="";
		this.stateError="";
		this.countryError="";
		this.zipcodeError="";
		this.drivinglicenseError="";
		this.licenseexpiryError="";
		this.issuingcountryError="";
		this.AACmemberError="";
		this.emailError="";
		this.dateofbirthError="";
		this.contactError="";	
	}
	
	public String getErrorMsg() {
		return errorMsg; 
	}

	public void setErrorMsg(SystemUser systemUser) { 
		
		if(!usernameError.equals("") || !passwordError.equals("") || !UTAIDError.equals("") || !firstnameError.equals("") || 
				!lastnameError.equals("") || !addressline1Error.equals("") || !addressline2Error.equals("") || !cityError.equals("") ||
				!stateError.equals("") || !countryError.equals("") || !zipcodeError.equals("") || !drivinglicenseError.equals("") ||
				!licenseexpiryError.equals("") || !issuingcountryError.equals("") || !emailError.equals("") || !dateofbirthError.equals("") ||
				!contactError.equals("")) {
			this.errorMsg = "Please correct the following errors:<br>";
			if(!usernameError.equals("")) {
				this.errorMsg = this.errorMsg + usernameError +"<br>";
			}
			if(!passwordError.equals("")) {
				this.errorMsg = this.errorMsg +  passwordError +"<br";
			}
			if(!UTAIDError.equals("")) {
				this.errorMsg = this.errorMsg +  UTAIDError +"<br>";
			}
			if(!firstnameError.equals("")) {
				this.errorMsg = this.errorMsg +  firstnameError +"<br>";
			}
			if(!lastnameError.equals("")) {
				this.errorMsg = this.errorMsg +  lastnameError +"<br>";
			}
			if(!addressline1Error.equals("")) {
				this.errorMsg = this.errorMsg +  addressline1Error +"<br>";
			}
			if(!addressline2Error.equals("")) {
				this.errorMsg = this.errorMsg +  addressline2Error +"<br>";
			}
			if(!cityError.equals("")) {
				this.errorMsg = this.errorMsg +  cityError +"<br>";
			}
			if(!stateError.equals("")) {
				this.errorMsg = this.errorMsg +  stateError +"<br>";
			}
			if(!countryError.equals("")) {
				this.errorMsg = this.errorMsg +  countryError +"<br>";
			}
			if(!zipcodeError.equals("")) {
				this.errorMsg = this.errorMsg +  zipcodeError +"<br>";
			}
			if(!drivinglicenseError.equals("")) {
				this.errorMsg = this.errorMsg +  drivinglicenseError +"<br>";
			}
			if(!licenseexpiryError.equals("")) {
				this.errorMsg = this.errorMsg +  licenseexpiryError +"<br>";
			}
			if(!issuingcountryError.equals("")) {
				this.errorMsg = this.errorMsg +  issuingcountryError +"<br>";
			}
			if(!emailError.equals("")) {
				this.errorMsg = this.errorMsg +  emailError +"<br>";
			}
			if(!dateofbirthError.equals("")) {
				this.errorMsg = this.errorMsg +  dateofbirthError +"<br>";
			}
			if(!contactError.equals("")) {
				this.errorMsg = this.errorMsg +  contactError +"<br>";
			}
		}
	}
	
	public String getUsernameError() {
		return usernameError;
	}

	public void setUsernameError(String usernameError) {
		this.usernameError = usernameError;
	}

	public String getPasswordError() {
		return passwordError;
	}

	public void setPasswordError(String passwordError) {
		this.passwordError = passwordError;
	}

	public String getRoleError() {
		return roleError;
	}

	public void setRoleError(String roleError) {
		this.roleError = roleError;
	}

	public String getUTAIDError() {
		return UTAIDError;
	}

	public void setUTAIDError(String uTAIDError) {
		UTAIDError = uTAIDError;
	}

	public String getFirstnameError() {
		return firstnameError;
	}

	public void setFirstnameError(String firstnameError) {
		this.firstnameError = firstnameError;
	}

	public String getLastnameError() {
		return lastnameError;
	}

	public void setLastnameError(String lastnameError) {
		this.lastnameError = lastnameError;
	}

	public String getAddressline1Error() {
		return addressline1Error;
	}

	public void setAddressline1Error(String addressline1Error) {
		this.addressline1Error = addressline1Error;
	}

	public String getAddressline2Error() {
		return addressline2Error;
	}

	public void setAddressline2Error(String addressline2Error) {
		this.addressline2Error = addressline2Error;
	}

	public String getCityError() {
		return cityError;
	}

	public void setCityError(String cityError) {
		this.cityError = cityError;
	}

	public String getStateError() {
		return stateError;
	}

	public void setStateError(String stateError) {
		this.stateError = stateError;
	}

	public String getCountryError() {
		return countryError;
	}
	public void setCountryError(String countryError){
		this.countryError = countryError;
	}
	
	
	public String getZipcodeError() {
		return zipcodeError;
	}

	public void setZipcodeError(String zipcodeError) {
		this.zipcodeError = zipcodeError;
	}

	public String getDrivinglicenseError() {
		return drivinglicenseError;
	}

	public void setDrivinglicenseError(String drivinglicenseError) {
		this.drivinglicenseError = drivinglicenseError;
	}

	public String getLicenseexpiryError() {
		return licenseexpiryError;
	}

	public void setLicenseexpiryError(String licenseexpiryError) {
		this.licenseexpiryError = licenseexpiryError;
	}

	public String getIssuingcountryError() {
		return issuingcountryError;
	}

	public void setIssuingcountryError(String issuingcountryError) {
		this.issuingcountryError = issuingcountryError;
	}

	public String getAACmemberError() {
		return AACmemberError;
	}

	public void setAACmemberError(String aACmemberError) {
		AACmemberError = aACmemberError;
	}

	public String getEmailError() {
		return emailError;
	}

	public void setEmailError(String emailError) {
		this.emailError = emailError;
	}

	public String getDateofbirthError() {
		return dateofbirthError;
	}

	public void setDateofbirthError(String dateofbirthError) {
		this.dateofbirthError = dateofbirthError;
	}

	public String getContactError() {
		return contactError;
	}

	public void setContactError(String contactError) {
		this.contactError = contactError;
	}
	
}

