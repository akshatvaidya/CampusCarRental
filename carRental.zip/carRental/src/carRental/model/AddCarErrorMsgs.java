package carRental.model;

public class AddCarErrorMsgs {
	private String errorMsg;
	private String nameError;
	private String weekDayRateError;
	private String weekendRateError;
	private String weekRateError;
	private String gpsRateError;
	private String onStarRateError;
	private String siriusXMRateError;
	
	public AddCarErrorMsgs() {
		this.errorMsg = "";
		this.nameError = "";
		this.weekDayRateError = "";
		this.weekendRateError = "";
		this.weekRateError = "";
		this.gpsRateError = "";
		this.onStarRateError = "";
		this.siriusXMRateError = "";
	}
	
	public void setErrorMsg(Car car) {
		if(!nameError.equals("") || !weekDayRateError.equals("") || !weekendRateError.equals("") || 
				!weekRateError.equals("") || !gpsRateError.equals("") || !onStarRateError.equals("")
				|| !siriusXMRateError.equals("")) {
			this.errorMsg = "Please correct the following errors:<br>";
			if(!nameError.equals("")) {
				this.errorMsg = this.errorMsg + nameError +"<br>";
			}
			if(!weekDayRateError.equals("")) {
				this.errorMsg = this.errorMsg + weekDayRateError +"<br>";
			}
			if(!weekendRateError.equals("")) {
				this.errorMsg = this.errorMsg + weekendRateError +"<br>";
			}
			if(!weekRateError.equals("")) {
				this.errorMsg = this.errorMsg + weekRateError +"<br>";
			}
			if(!gpsRateError.equals("")) {
				this.errorMsg = this.errorMsg + gpsRateError +"<br>";
			}
			if(!onStarRateError.equals("")) {
				this.errorMsg = this.errorMsg + onStarRateError +"<br>";
			}
			if(!siriusXMRateError.equals("")) {
				this.errorMsg = this.errorMsg + siriusXMRateError +"<br>";
			}
		}
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getNameError() {
		return nameError;
	}

	public void setNameError(String nameError) {
		this.nameError = nameError;
	}

	public String getWeekDayRateError() {
		return weekDayRateError;
	}

	public void setWeekDayRateError(String weekDayRateError) {
		this.weekDayRateError = weekDayRateError;
	}

	public String getWeekendRateError() {
		return weekendRateError;
	}

	public void setWeekendRateError(String weekendRateError) {
		this.weekendRateError = weekendRateError;
	}

	public String getWeekRateError() {
		return weekRateError;
	}

	public void setWeekRateError(String weekRateError) {
		this.weekRateError = weekRateError;
	}

	public String getGpsRateError() {
		return gpsRateError;
	}

	public void setGpsRateError(String gpsRateError) {
		this.gpsRateError = gpsRateError;
	}

	public String getOnStarRateError() {
		return onStarRateError;
	}

	public void setOnStarRateError(String onStarRateError) {
		this.onStarRateError = onStarRateError;
	}

	public String getSiriusXMRateError() {
		return siriusXMRateError;
	}

	public void setSiriusXMRateError(String siriusXMRateError) {
		this.siriusXMRateError = siriusXMRateError;
	}
	
	
	
	
}
