package carRental.model;

import carRental.data.AdminDAO;


public class RevokeValidation {
	private String wrongUsername="";
	
	
	public String ValidateUsername(String username) {

		boolean flag=false;
		
		AdminDAO adao = new AdminDAO();
		flag = adao.checkUsername(username);
		if (flag==false){
			this.setwrongUsername();
		}
		return this.wrongUsername;
	}
	
	public void setwrongUsername(){
		this.wrongUsername = "Username does not exist";
	}
	
	public String getWrongUsername(){
		return this.wrongUsername;
	}

}
