 package carRental.controller;

import java.io.IOException;
import java.util.ArrayList;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import carRental.data.RentalManagerDAO;
import carRental.data.ReservationDAO;
import carRental.data.SystemUserDAO;
import carRental.model.AddCarErrorMsgs;
import carRental.model.BookedReservations;
import carRental.model.Car;
import carRental.model.Reservations;
import carRental.model.SystemUser;
import carRental.model.SystemUserErrorMsgs;

import carRental.model.requestRentalErrorMsgs;

@WebServlet("/RentalManagerController")
public class RentalManagerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		if(request.getParameter("Logout")!=null) {
			HttpSession session = request.getSession();
			session.invalidate();
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		else if(request.getParameter("viewCars") != null) {
			HttpSession session = request.getSession();
			if(request.getParameter("Occupants").equals("") || request.getParameter("Sdate").equals("") || 
					request.getParameter("Edate").equals("") || request.getParameter("Ptime").equals("") || 
					request.getParameter("Dtime").equals("")) {
				session.setAttribute("errorMsg", 1);
				RequestDispatcher dispatcher = request.getRequestDispatcher("searchAvailableCars.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			else {
				int capacity = Integer.parseInt(request.getParameter("Occupants"));
				String sdate = request.getParameter("Sdate");
				String edate = request.getParameter("Edate");
				String ptime = request.getParameter("Ptime");
				String dtime = request.getParameter("Dtime");
				
				Reservations reservations = new Reservations();
				try {
					reservations.setReservation(capacity, sdate, edate, ptime, dtime);
				}
				catch(Exception e) {
					System.out.println(e);
				}
				requestRentalErrorMsgs reservationErrorMsgs = new requestRentalErrorMsgs();
				reservations.validateReservation(reservations, reservationErrorMsgs);
				
				session.setAttribute("reservationErrorMsgs", reservationErrorMsgs);
				
				if(reservationErrorMsgs.getErrorMsg().equals("")) {
					ArrayList<Car> availableCars = new ArrayList<Car>();
					availableCars = ReservationDAO.searchCars(reservations);
					session.setAttribute("availableCars", availableCars);
					session.setAttribute("reservation", reservations);
					RequestDispatcher dispatcher = request.getRequestDispatcher("managerAvailableCars.jsp");
					dispatcher.forward(request, response);
					response.setContentType("text/html");
				}
				else {
					
					RequestDispatcher dispatcher = request.getRequestDispatcher("searchAvailableCars.jsp");
					dispatcher.forward(request, response);
					response.setContentType("text/html");
				}
			
			}
			}
		else if(request.getParameter("addacar")!=null) {
			HttpSession session = request.getSession();
			Car car = new Car();
			car.setCar(request.getParameter("Car"), request.getParameter("Occupants"), request.getParameter("rate"), 
					request.getParameter("wrate"), request.getParameter("weekrate"), request.getParameter("GPS"), 
					request.getParameter("SiriuxXM"), request.getParameter("Onstar"));
			//AddACarValidation carvalid=new AddACarValidation();
			AddCarErrorMsgs errorMsgs = new AddCarErrorMsgs();
			car.validateCar(car, errorMsgs);
			session.setAttribute("car", car);
			session.setAttribute("errorMsgs", errorMsgs);

			if(errorMsgs.getErrorMsg().equals("")){
				RentalManagerDAO rdao = new RentalManagerDAO();
				rdao.addCar(car);
				//rdao.insertCar(car,occ,weekdayrate,weekendrate,weekrate,gps,onstar,SiriuxXM);
				session.setAttribute("carAdded", "Car Added Successfully");
				RequestDispatcher dispatcher = request.getRequestDispatcher("managerhome.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}

			else{
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("addacar.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");

			}
		}
		else if(request.getParameter("sR")!= null) {
			HttpSession session = request.getSession();
			String month = request.getParameter("month");
			String year = request.getParameter("year");
			System.out.println(month);
			System.out.println(year);
			ReservationDAO dao = new ReservationDAO();
			ArrayList<BookedReservations> br = new ArrayList<BookedReservations>();
			br = dao.getReservations(month,year);
			
			if(!br.isEmpty()) {
				session.setAttribute("searchedR", br);
				System.out.println("asdsaasd");
				RequestDispatcher dispatcher = request.getRequestDispatcher("searchedReservations.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("viewReservations.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			
		}
		else if(request.getParameter("DeleteRental") != null) {
			HttpSession session = request.getSession();
			boolean isDeleted = false;
			int rid = Integer.parseInt(request.getParameter("rid"));
			ReservationDAO rdao = new ReservationDAO();
			isDeleted = rdao.deleteRental(rid);
			if(isDeleted == true) {
				session.setAttribute("rentalDeleted", isDeleted);
				RequestDispatcher dispatcher = request.getRequestDispatcher("managerhome.jsp");
				
				dispatcher.forward(request, response);
				response.setContentType("text/html");
				session.removeAttribute("reantalDeleted");
				
			}
		}
		else if(request.getParameter("managerupdate")!=null){
			HttpSession session = request.getSession();
			String username = (String) session.getAttribute("rentalmanager");
			ArrayList<String> details = new ArrayList<String>();
			details = SystemUserDAO.getSystemUser(username);
			session.setAttribute("userdetails", details);
			RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateUserProfile.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}	
		else if(request.getParameter("ManagerUpdate")!=null) {
			
			HttpSession session = request.getSession();
			SystemUser systemuser = new SystemUser();
			try {
				
				systemuser.setSystemUser((String) session.getAttribute("rentalmanager"),request.getParameter("psw") ,request.getParameter("role"), 
						request.getParameter("utaid"), request.getParameter("fname"), request.getParameter("lname"),
						request.getParameter("aline1"), request.getParameter("aline2"), request.getParameter("city"), request.getParameter("state"), 
						request.getParameter("country"), request.getParameter("zipcode"), request.getParameter("dl"), request.getParameter("lexpiry"),
						request.getParameter("icountry"), request.getParameter("aac"), request.getParameter("email"), request.getParameter("dob"), 
						request.getParameter("contact"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			SystemUserErrorMsgs SUerrorMsgs = new SystemUserErrorMsgs();
			systemuser.validateUpdatingSystemUser(SUerrorMsgs);
			session.setAttribute("systemUser", systemuser);
			session.setAttribute("errorMsgs", SUerrorMsgs);
			
			if(SUerrorMsgs.getErrorMsg().equals("")) {
				SystemUserDAO.UpdateUser(systemuser);
				boolean flag = true;
				ArrayList<String> userDetails = new ArrayList<String>();
				userDetails = SystemUserDAO.getSystemUser(systemuser.getUsername());
				session.removeAttribute("userdetails");
				session.setAttribute("userdetails", userDetails);
				session.setAttribute("profileUpdated", flag);
				RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateUserProfile.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateUserProfile.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			
		}	
			
	}
	
}
