package carRental.controller;


import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import carRental.data.SystemUserDAO;
import carRental.model.SystemUser;
import carRental.model.SystemUserErrorMsgs;


@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		SystemUser systemuser = new SystemUser();
		systemuser.setSystemUser(request.getParameter("uname"), request.getParameter("psw"), request.getParameter("role"), 
					request.getParameter("utaid"), request.getParameter("Fname"), request.getParameter("Lname"),
					request.getParameter("Aline1"), request.getParameter("Aline2"), request.getParameter("City"), request.getParameter("State"), 
					request.getParameter("Country"), request.getParameter("Zipcode"), request.getParameter("Lnum"), request.getParameter("lexpiry"),
					request.getParameter("ICountry"), request.getParameter("AAC"), request.getParameter("Email"), request.getParameter("date"), 
					request.getParameter("Phone"));

		SystemUserErrorMsgs SUerrorMsgs = new SystemUserErrorMsgs();
		systemuser.validateSystemUser(systemuser, SUerrorMsgs);
		session.setAttribute("systemUser", systemuser);
		session.setAttribute("errorMsgs", SUerrorMsgs);
		
		if(SUerrorMsgs.getErrorMsg().equals("")) {
			SystemUserDAO.insertSystemUser(systemuser);
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("registration.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}

	}
}
