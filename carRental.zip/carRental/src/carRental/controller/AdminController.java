package carRental.controller;

import java.io.IOException;

import java.util.ArrayList;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carRental.data.AdminDAO;
import carRental.data.SystemUserDAO;
import carRental.model.RevokeValidation;
import carRental.model.SystemUser;
import carRental.model.SystemUserErrorMsgs;


@WebServlet("/AdminController") 
public class AdminController extends HttpServlet { 
	private static final long serialVersionUID = 1L;
	String message = "";
	String result = "";
	String role="";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	@SuppressWarnings("static-access")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		if(request.getParameter("revoke_search")!=null) {
			HttpSession session = request.getSession();
			if(request.getParameter("uname").equals("")) {
				session.setAttribute("errorMsg", 1);
				RequestDispatcher dispatcher = request.getRequestDispatcher("revoke.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			else {
				String username = request.getParameter("uname");
				session.setAttribute("userSelected", username);
				RevokeValidation revValid=new RevokeValidation();

				if(revValid.ValidateUsername(username).equals("")){
					AdminDAO dao2 = new AdminDAO();
					boolean flag = dao2.checkIfRevoked(username);
					if(flag == true) {
						session.setAttribute("AlreadyRevoked", flag);
						RequestDispatcher dispatcher = request.getRequestDispatcher("revoke.jsp");
						dispatcher.forward(request, response);
						response.setContentType("text/html");
					}
					else {
						SystemUserDAO dao = new SystemUserDAO();
						try{
						ArrayList<String> details = new ArrayList<String>();
						details = dao.getSystemUser(username);
		
						if(details.get(2).equalsIgnoreCase("admin") || details.get(2).equalsIgnoreCase("rental manager")) {
							session.removeAttribute("errorMsg");
							session.removeAttribute("errorMsg2");
							session.setAttribute("errorMsg3", 1);
							RequestDispatcher dispatcher = request.getRequestDispatcher("revoke.jsp");
							dispatcher.forward(request, response);
							response.setContentType("text/html");
						}
						else {
							session.setAttribute("userdetails", details);
							RequestDispatcher dispatcher = request.getRequestDispatcher("revoke_next.jsp");
							dispatcher.forward(request, response);
							response.setContentType("text/html");
						}				
						}
						catch(Exception e) {
							System.out.println(e);
						}
					}
				}
				else {
					session.removeAttribute("errorMsg");	
					session.setAttribute("errorMsg2", 1);
					RequestDispatcher dispatcher = request.getRequestDispatcher("revoke.jsp");
					dispatcher.forward(request, response);
					response.setContentType("text/html");
				}
			}
					}
		else if(request.getParameter("Logout")!=null) {
			HttpSession session = request.getSession();
			session.invalidate();
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		else if(request.getParameter("revoke_button")!=null) {
			HttpSession session = request.getSession();
			String username = (String) session.getAttribute("userSelected");
			revoke_user(username, request, response);
		
		}
		else if(request.getParameter("adminUpdate")!=null) {
			HttpSession session = request.getSession();
			String username = (String) session.getAttribute("admin");
			ArrayList<String> details = new ArrayList<String>();
			details = SystemUserDAO.getSystemUser(username);
			session.setAttribute("userdetails", details);
			RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateProfile.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		else if(request.getParameter("AdminUpdate")!=null){
			HttpSession session = request.getSession();
			SystemUser systemuser = new SystemUser();
			try {		
				systemuser.setSystemUser((String) session.getAttribute("admin"),request.getParameter("psw") ,request.getParameter("role"), 
						request.getParameter("utaid"), request.getParameter("fname"), request.getParameter("lname"),
						request.getParameter("aline1"), request.getParameter("aline2"), request.getParameter("city"), request.getParameter("state"), 
						request.getParameter("country"), request.getParameter("zipcode"), request.getParameter("dl"), request.getParameter("lexpiry"),
						request.getParameter("icountry"), request.getParameter("aac"), request.getParameter("email"), request.getParameter("dob"), 
						request.getParameter("contact"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			SystemUserErrorMsgs SUerrorMsgs = new SystemUserErrorMsgs();
			systemuser.validateUpdatingSystemUser(SUerrorMsgs);
			session.setAttribute("systemUser", systemuser);
			session.setAttribute("errorMsgs", SUerrorMsgs);
			
			if(SUerrorMsgs.getErrorMsg().equals("")) {
				System.out.println("I aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
				SystemUserDAO.UpdateUser(systemuser);
				boolean flag1 = true;
				ArrayList<String> userDetails = new ArrayList<String>();
				userDetails = SystemUserDAO.getSystemUser(systemuser.getUsername());
				session.removeAttribute("userdetails");
				session.setAttribute("userdetails", userDetails);
				session.setAttribute("profileUpdated", flag1);
				RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateProfile.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
					}
			else {
				System.out.println("bc");
				session.removeAttribute("profileUpdated");
				RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateProfile.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
		}
		else if(request.getParameter("searchUserForUpdate")!=null) {
			HttpSession session = request.getSession();
			if(request.getParameter("uname").equals("")) {
				session.setAttribute("errorMsg", 1);
				RequestDispatcher dispatcher = request.getRequestDispatcher("editUserProfile.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			else {
				String username = request.getParameter("uname");
				session.setAttribute("userSelectedForUpdate", request.getParameter("uname"));
				RevokeValidation revValid=new RevokeValidation();

				if(revValid.ValidateUsername(username).equals("")){			
					SystemUserDAO dao = new SystemUserDAO();
					try{
					ArrayList<String> details = new ArrayList<String>();
					details = dao.getSystemUser(username);
					session.setAttribute("userdetails", details);
					RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateUser.jsp");
					dispatcher.forward(request, response);
					response.setContentType("text/html");
					}
					catch(Exception e) {
						System.out.println(e);
					}
				}
				else {
					session.setAttribute("errorMsg2", 1);
					RequestDispatcher dispatcher = request.getRequestDispatcher("editUserProfile.jsp");
					dispatcher.forward(request, response);
					response.setContentType("text/html");
				}
			}
					}
			else if(request.getParameter("AdminUserUpdate")!=null) {
	
				HttpSession session = request.getSession();
				SystemUser systemuser = new SystemUser();
				try {		
					systemuser.setSystemUser((String) session.getAttribute("userSelectedForUpdate"),request.getParameter("psw") ,request.getParameter("role"), 
							request.getParameter("utaid"), request.getParameter("fname"), request.getParameter("lname"),
							request.getParameter("aline1"), request.getParameter("aline2"), request.getParameter("city"), request.getParameter("state"), 
							request.getParameter("country"), request.getParameter("zipcode"), request.getParameter("dl"), request.getParameter("lexpiry"),
							request.getParameter("icountry"), request.getParameter("aac"), request.getParameter("email"), request.getParameter("dob"), 
							request.getParameter("contact"));
				} catch (Exception e) {
					e.printStackTrace();
				} 
				SystemUserErrorMsgs SUerrorMsgs = new SystemUserErrorMsgs();
				systemuser.validateUpdatingSystemUser(SUerrorMsgs);
				session.setAttribute("systemUser", systemuser);
				session.setAttribute("errorMsgs", SUerrorMsgs);
				
				if(SUerrorMsgs.getErrorMsg().equals("")) {
					SystemUserDAO.UpdateUser(systemuser);
					boolean flag1 = true;
					ArrayList<String> userDetails = new ArrayList<String>();
					userDetails = SystemUserDAO.getSystemUser(systemuser.getUsername());
					session.removeAttribute("userdetails");
					session.setAttribute("userdetails", userDetails);
					session.setAttribute("profileUpdated", flag1);
					RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateUser.jsp");
					dispatcher.forward(request, response);
					response.setContentType("text/html");
				
				}
				else {
					session.removeAttribute("profileUpdated");
					RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateUser.jsp");
					dispatcher.forward(request, response);
					response.setContentType("text/html");
				}
			}
	}
	public void revoke_user(String username, HttpServletRequest request, HttpServletResponse response) {
		
		try {
			HttpSession session = request.getSession();
			AdminDAO adao = new AdminDAO();
			adao.revokeUser(username);
			boolean flag = true;
			session.setAttribute("message", flag);
			RequestDispatcher dispatcher = request.getRequestDispatcher("adminhome.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}
