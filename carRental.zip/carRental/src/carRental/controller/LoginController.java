package carRental.controller;


import java.io.IOException;

import java.util.ArrayList;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carRental.data.SystemUserDAO;

import carRental.model.LoginErrorMsgs;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    String message = "";
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("uname");
		String password = request.getParameter("psw");
		
		LoginErrorMsgs errorMsgs = new LoginErrorMsgs();

		HttpSession session = request.getSession();

		ArrayList<String> list = new ArrayList<String>();
		list = SystemUserDAO.getSystemUser(username);
		if(list.isEmpty()) {
			errorMsgs.setErrorMsg("No user found with the provided username");
			session.setAttribute("errorMsg", errorMsgs.getErrorMsg());
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		else {
			String psw = list.get(1).toString();
			String role=list.get(2).toString();
		
			if(role.equals("Admin") && (password.equals(psw)) ){
				session = request.getSession();
			
				session.setAttribute("username", username);
				session.setAttribute("admin", username);
				session.setAttribute("details", list);
				getServletContext().getRequestDispatcher("/adminhome.jsp").forward(request, response);
			}
			else if(role.equals("User") && (password.equals(psw))){
				session = request.getSession();
				session.setAttribute("username", username);
				session.setAttribute("user", username);
				session.setAttribute("details", list);
				getServletContext().getRequestDispatcher("/userhome.jsp").forward(request, response);	
			}
			else if(role.equals("Rental Manager") && (password.equals(psw))){
				session = request.getSession();
				session.setAttribute("username", username);
				session.setAttribute("rentalmanager", username);
				session.setAttribute("details", list);
				getServletContext().getRequestDispatcher("/managerhome.jsp").forward(request, response);	
			}
			else {
				errorMsgs.setErrorMsg("Either the username or the password entered is wrong");
				session.setAttribute("errorMsg", errorMsgs.getErrorMsg());
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}	
		}
	}
}

