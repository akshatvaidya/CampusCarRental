package carRental.controller;


import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carRental.data.ReservationDAO;
import carRental.data.SystemUserDAO;
import carRental.model.BookedReservations;
import carRental.model.Car;
import carRental.model.Reservations;
import carRental.model.SystemUser;
import carRental.model.SystemUserErrorMsgs;
import carRental.model.booking;
import carRental.model.makePaymentErrorMsgs;
import carRental.model.payment;
import carRental.model.requestRentalErrorMsgs;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
	doPost(request, response);
}

@SuppressWarnings("unchecked")
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	if(request.getParameter("searchCar")!= null) {
		HttpSession session = request.getSession();
			int capacity = 1;
			if(request.getParameter("Occupants").equals("")) {
				capacity = 0;
			}
			if(capacity != 0) {
				capacity = Integer.parseInt(request.getParameter("Occupants"));
			}
			
			String sdate = request.getParameter("Sdate");
		
			String edate = request.getParameter("Edate");
		
			String ptime = request.getParameter("Ptime");
	
			String dtime = request.getParameter("Dtime");

			Reservations reservations = new Reservations();
			try {
				reservations.setReservation(capacity, sdate, edate, ptime, dtime);
			}
			catch(Exception e) {
				System.out.println(e + "adasda");
			}
			System.out.println(reservations.getNoOfOccupants());
			requestRentalErrorMsgs reservationErrorMsgs = new requestRentalErrorMsgs();
			reservations.validateReservation(reservations, reservationErrorMsgs);
			
			session.setAttribute("reservationErrorMsgs", reservationErrorMsgs);
			
			if(reservationErrorMsgs.getErrorMsg().equals("")) {
				ArrayList<Car> availableCars = new ArrayList<Car>();
				availableCars = ReservationDAO.searchCars(reservations);
				//System.out.println(availableCars);
				session.setAttribute("availableCars", availableCars);
				session.setAttribute("reservation", reservations);
				RequestDispatcher dispatcher = request.getRequestDispatcher("availableCars.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
			else {
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("bookACar.jsp");
				dispatcher.forward(request, response);
				response.setContentType("text/html");
			}
	}
	else if(request.getParameter("requestRentals") != null) {
		boolean revoked = false;
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("user");
		SystemUserDAO rev = new SystemUserDAO();
		revoked = rev.checkRevoked(username);
		if(revoked == true){
			//System.out.println(revoked);
			session.setAttribute("revoked", revoked);
			RequestDispatcher dispatcher = request.getRequestDispatcher("userhome.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("bookACar.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		
	}
	else if(request.getParameter("Logout")!=null) {
		HttpSession session = request.getSession();
		session.invalidate();
		RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
		dispatcher.forward(request, response);
		response.setContentType("text/html");
	}
	else if(request.getParameter("addExtras") != null) {
		double extrasCost = 0.0d;
		HttpSession session = request.getSession();
		String[] extras = request.getParameterValues("extras");
		System.out.println(extras.length);
		for(String e: extras) {
			System.out.println(e + "pahila");
		}
		ArrayList<String> extrasSelected = new ArrayList<String>(); 
		int i = 0;
		for(String feature : extras) {
			if(i == 0) {
				extrasSelected.add("gps");
			}
			else if(i == 1) {
				extrasSelected.add("onstar");
			}
			else if(i == 2) {
				extrasSelected.add("siriusxm");
			}
			extrasCost += Double.parseDouble(feature);
			i++;
			}
		session.setAttribute("extrasCost", extrasCost);
		session.setAttribute("listOfExtras", extrasSelected);
		RequestDispatcher dispatcher = request.getRequestDispatcher("availableCars.jsp");
		dispatcher.forward(request, response);
		response.setContentType("text/html");
		
	}
	else if(request.getParameter("selectCar") != null) {
		HttpSession session = request.getSession();
		double extrasCost;
		double totalCost = 0.0d;
		String selectedCar = request.getParameter("car");
		session.setAttribute("selectedCar", selectedCar);
		booking booking = new booking();
		Reservations reservation = (Reservations) session.getAttribute("reservation");
		if(session.getAttribute("extrasCost") != null) {
			extrasCost = (double) session.getAttribute("extrasCost");
		}
		else {
			extrasCost = 0.0d;
		}
		String username = (String) session.getAttribute("user");

		boolean member = SystemUserDAO.checkIfAACMember(username);
		totalCost = booking.calculateInvoice(selectedCar, reservation, extrasCost, member);

		session.setAttribute("totalCost", totalCost);
		RequestDispatcher dispatcher = request.getRequestDispatcher("invoice.jsp");
		dispatcher.forward(request, response);
		response.setContentType("text/html");
	}
	else if(request.getParameter("pay") != null) {
		HttpSession session = request.getSession();
		String nameOnCard = request.getParameter("fullname");
		String cardType = request.getParameter("cardtype");
		String cardNumber = request.getParameter("cardnumber");
		String month = request.getParameter("month");
		String year = request.getParameter("year");
		String cvv = request.getParameter("cvv");

		String expiry = year + "-" + month + "-28";
		payment p = new payment();
		String errorMsg = "";
		p.setPayment(nameOnCard, cardType, cardNumber, expiry, cvv);
		makePaymentErrorMsgs errorMsgs = new makePaymentErrorMsgs();
		p.validatePayment(errorMsgs,errorMsg);

		session.setAttribute("paymentErrorMsgs", errorMsgs);
		
		if(errorMsgs.getErrorMsg().equals("")) {
	
			String username = (String) session.getAttribute("user");
			ArrayList<String> extrasss = new ArrayList<String>();
			if(session.getAttribute("listOfExtras")!= null) {
				extrasss = (ArrayList<String>) session.getAttribute("listOfExtras");
			}
			String carSelected = (String) session.getAttribute("selectedCar");
			Reservations reservation = (Reservations) session.getAttribute("reservation");
			double totalCost = (double) session.getAttribute("totalCost");
	
			try {
				ReservationDAO.addReservation(username, reservation, totalCost, extrasss, carSelected);
			} catch (SQLException e) {

				e.printStackTrace();
			}
			String result = "Payment was successful";
			session.setAttribute("paymentSuccess", result);
			session.removeAttribute("paymentErrorMsgs");
			RequestDispatcher dispatcher = request.getRequestDispatcher("paymentconfirmation.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		
		}
		else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("paymentconfirmation.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		
	}
	
	else if(request.getParameter("viewRentals") != null) {
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("user");
		ArrayList<BookedReservations> br = new ArrayList<BookedReservations>();
		SystemUserDAO dao = new SystemUserDAO();
		br = dao.viewMyRentals(username);
		session.setAttribute("myrentals", br);
		RequestDispatcher dispatcher = request.getRequestDispatcher("ViewMyRentals.jsp");
		dispatcher.forward(request, response);
		response.setContentType("text/html");
	}
	else if(request.getParameter("DeleteRental") != null) {
		HttpSession session = request.getSession();
		boolean isDeleted = false;
		int rid = Integer.parseInt(request.getParameter("rid"));
		ReservationDAO rdao = new ReservationDAO();
		isDeleted = rdao.deleteRental(rid);
		if(isDeleted == true) {
			session.setAttribute("rentalDeleted", isDeleted);
			RequestDispatcher dispatcher = request.getRequestDispatcher("userhome.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
			
		}
	}
	else if(request.getParameter("userUpdate") != null) {
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("user");
		ArrayList<String> details = new ArrayList<String>();
		details = SystemUserDAO.getSystemUser(username);
		session.setAttribute("userdetails", details);
		RequestDispatcher dispatcher = request.getRequestDispatcher("userUpdate.jsp");
		dispatcher.forward(request, response);
		response.setContentType("text/html");
	}
	else if(request.getParameter("UserUpdate") != null) {
		HttpSession session = request.getSession();
		SystemUser systemuser = new SystemUser();	
		String username = session.getAttribute("user").toString();
		systemuser.setSystemUser(username,request.getParameter("psw") ,request.getParameter("role"), 
					request.getParameter("utaid"), request.getParameter("fname"), request.getParameter("lname"),
					request.getParameter("aline1"), request.getParameter("aline2"), request.getParameter("city"), request.getParameter("state"), 
					request.getParameter("country"), request.getParameter("zipcode"), request.getParameter("dl"), request.getParameter("lexpiry"),
					request.getParameter("icountry"), request.getParameter("aac"), request.getParameter("email"), request.getParameter("dob"), 
					request.getParameter("contact"));

		SystemUserErrorMsgs SUerrorMsgs = new SystemUserErrorMsgs();
		systemuser.validateUpdatingSystemUser(SUerrorMsgs);
		session.setAttribute("systemUser", systemuser);
		session.setAttribute("errorMsgs", SUerrorMsgs);
		System.out.println(systemuser.getCountry());
		System.out.println(SUerrorMsgs.getPasswordError());
		System.out.println(SUerrorMsgs.getCountryError());
		
		if(SUerrorMsgs.getErrorMsg().equals("")) {
			SystemUserDAO.UpdateUser(systemuser);
			boolean flag = true;
			ArrayList<String> userDetails = new ArrayList<String>();
			userDetails = SystemUserDAO.getSystemUser(systemuser.getUsername());
			session.removeAttribute("userdetails");
			session.setAttribute("userdetails", userDetails);
			session.setAttribute("profileUpdated", flag);
			RequestDispatcher dispatcher = request.getRequestDispatcher("userUpdate.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
		else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("userUpdate.jsp");
			dispatcher.forward(request, response);
			response.setContentType("text/html");
		}
	}	
}
}
	

