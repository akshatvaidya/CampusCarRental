package carRental.functions;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import java.util.Properties;

public class carRental_BusinessFunctions {
	public static Properties prop;
	public static WebDriver driver;

	public void CR_BF_Login(WebDriver driver, String UserName, String Password){
		driver.findElement(By.xpath(prop.getProperty("Login_Txt_Username"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Login_Txt_Username"))).sendKeys(UserName);
	    driver.findElement(By.xpath(prop.getProperty("Login_Txt_Password"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Login_Txt_Password"))).sendKeys(Password);
	    driver.findElement(By.xpath(prop.getProperty("Login_btn_login"))).click();
	}
	
	
	
	public void CR_BF_Registration(WebDriver driver, String UserName, String Password, String UTAID, String FirstName,
			String LastName, String Role, String BirthDate, String AddressLine1, String AddressLine2, 
			String City, String State, String Zipcode, String Country, String DLNumber, String DLExpiry,
			String IssuingCountry, String AACMember, String Email, String Contact){
		driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Username"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Username"))).sendKeys(UserName);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Password"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Password"))).sendKeys(Password);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_UTAID"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_UTAID"))).sendKeys(UTAID);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_FirstName"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_FirstName"))).sendKeys(FirstName);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_LastName"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_LastName"))).sendKeys(LastName);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Role"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Role"))).sendKeys(Role);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_DateOfBirth"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_DateOfBirth"))).sendKeys(BirthDate);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_AddLine1"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_AddLine1"))).sendKeys(AddressLine1);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_AddLine2"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_AddLine2"))).sendKeys(AddressLine2);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_City"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_City"))).sendKeys(City);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_State"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_State"))).sendKeys(State);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_ZipCode"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_ZipCode"))).sendKeys(Zipcode);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Country"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Country"))).sendKeys(Country);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_LicNumber"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_LicNumber"))).sendKeys(DLNumber);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_LicExp"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_LicExp"))).sendKeys(DLExpiry);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_IssueCountry"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_IssueCountry"))).sendKeys(IssuingCountry);
	    if(AACMember.equalsIgnoreCase("yes")) {
	 	    driver.findElement(By.xpath(prop.getProperty("Registration_RadioButton_Yes"))).click();
	    }
	    else {
	    	driver.findElement(By.xpath(prop.getProperty("Registration_RadioButton_No"))).click();
	    }
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Email"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Email"))).sendKeys(Email);
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Contact"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("Registration_Txt_Contact"))).sendKeys(Contact);   
	    driver.findElement(By.xpath(prop.getProperty("Registration_Btn_Register"))).click();
	}
	
	
	public void CR_BF_Updateprofile(WebDriver driver, String Password, String UTAID, String FirstName,
			String LastName, String BirthDate, String AddressLine1, String AddressLine2, 
			String City, String State, String Zipcode, String Country, String DLNumber, String DLExpiry,
			String IssuingCountry, String AACMember, String Email, String Contact){
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Password"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Password"))).sendKeys(Password);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_UTAID"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_UTAID"))).sendKeys(UTAID);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_FirstName"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_FirstName"))).sendKeys(FirstName);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_LastName"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_LastName"))).sendKeys(LastName);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_AddLine1"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_AddLine1"))).sendKeys(AddressLine1);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_AddLine2"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_AddLine2"))).sendKeys(AddressLine2);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_City"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_City"))).sendKeys(City);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_State"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_State"))).sendKeys(State);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Country"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Country"))).sendKeys(Country);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_ZipCode"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_ZipCode"))).sendKeys(Zipcode);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_LicNumber"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_LicNumber"))).sendKeys(DLNumber);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_LicExp"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_LicExp"))).sendKeys(DLExpiry);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_IssueCountry"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_IssueCountry"))).sendKeys(IssuingCountry);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_AACMember"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_AACMember"))).sendKeys(AACMember);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Email"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Email"))).sendKeys(Email);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_DOB"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_DOB"))).sendKeys(BirthDate);
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Contact"))).clear();
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Txt_Contact"))).sendKeys(Contact);   
	    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Btn_Update"))).click();
	}
	
	
	public void CR_BF_Revokerenter(WebDriver driver, String UserName){
		 driver.findElement(By.xpath(prop.getProperty("RevokeReneter_Txt_Username"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("RevokeReneter_Txt_Username"))).sendKeys(UserName);
		 driver.findElement(By.xpath(prop.getProperty("RevokeReneter_Btn_searchUser"))).click();
	}
	
	
	
	public void CR_BF_SearchCar(WebDriver driver, String Capacity, String StartDate, String EndDate, 
			String PickUpTime, String DropOffTime){
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Lst_Occupants"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Lst_Occupants"))).sendKeys(Capacity);
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_StartDate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_StartDate"))).sendKeys(StartDate);
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_EndDate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_EndDate"))).sendKeys(EndDate);
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_PickupTime"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_PickupTime"))).sendKeys(PickUpTime);
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_DropoffTime"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Txt_DropoffTime"))).sendKeys(DropOffTime);
		 driver.findElement(By.xpath(prop.getProperty("RequestRental_Btn_searchCars"))).click();
	}
	
	
	public void CR_BF_makepayment(WebDriver driver, String NameOnCard, String CardType, String CardNumber,
			String ExpirationMonth, String ExpirationYear, String CVV){
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Txt_nameOnCard"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Txt_nameOnCard"))).sendKeys(NameOnCard);
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Lst_cardType"))).sendKeys(CardType);
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Txt_cardNumber"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Txt_cardNumber"))).sendKeys(CardNumber);
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Lst_expirationMonth")));
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Lst_expirationMonth"))).sendKeys(ExpirationMonth);
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Lst_expirationYear")));
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Lst_expirationYear"))).sendKeys(ExpirationYear);
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Txt_Cvv"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Txt_Cvv"))).sendKeys(CVV);
		 driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Btn_Pay"))).click();
	}
	

	public void CR_BF_ViewCalender(WebDriver driver, String Month, String Year){
		driver.findElement(By.xpath(prop.getProperty("ViewCalender_Lst_month"))).sendKeys(Month);
		driver.findElement(By.xpath(prop.getProperty("ViewCalender_Lst_year"))).sendKeys(Year);
		driver.findElement(By.xpath(prop.getProperty("ViewCalender_Btn_searchReservations"))).click();
	}
	
	
	
	public void CR_BF_viewavailablecar(WebDriver driver, String Capacity, String StartDate, String EndDate, String PickUpTime,
			String DropOffTime){
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Lst_occupants"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Lst_occupants"))).sendKeys(Capacity);
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_StartDate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_StartDate"))).sendKeys(StartDate);
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_EndDate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_EndDate"))).sendKeys(EndDate);
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_PickUpTime"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_PickUpTime"))).sendKeys(PickUpTime);
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_DropoffTime"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Txt_DropoffTime"))).sendKeys(DropOffTime);
		 driver.findElement(By.xpath(prop.getProperty("SearchCars_Btn_SearchCar"))).click();
	}
	

	
	public void CR_BF_AddCar(WebDriver driver, String CarName, String Capacity, String WeekDayRate, String WeekendRate,
			String WeekRate, String GPSRate, String OnStarRate, String SiriusXMRate){
		driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_CarName"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_CarName"))).sendKeys(CarName);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_Capacity"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_Capacity"))).sendKeys(Capacity);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_WeekdayRate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_WeekdayRate"))).sendKeys(WeekDayRate);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_WeekendRate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_WeekendRate"))).sendKeys(WeekendRate);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_WeekRate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_WeekRate"))).sendKeys(WeekRate);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_GPSRate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_GPSRate"))).sendKeys(GPSRate);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_OnStarRate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_OnStarRate"))).sendKeys(OnStarRate);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_SiriusXMRate"))).clear();
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Txt_SiriusXMRate"))).sendKeys(SiriusXMRate);
		 driver.findElement(By.xpath(prop.getProperty("AddCar_Btn_AddCar"))).click();
	}

}