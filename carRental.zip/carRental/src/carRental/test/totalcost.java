package carRental.test;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import carRental.model.booking;
import carRental.model.makePaymentErrorMsgs;
import carRental.model.CarErrorMsgs;
import carRental.model.Reservations;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class totalcost {
	
	

		private booking booking;
		private makePaymentErrorMsgs payerror;
//		private CarErrorMsgs carErrorMsgs;
		
		@Before
		public void setUp() {
			booking = new booking();
			payerror=new makePaymentErrorMsgs();
			//carErrorMsgs = new CarErrorMsgs();
		}
	@Test
	@FileParameters("testCases/totalcost.csv")
	public void test(int testcaseNumber, String carName, String startDate, String endDate, String startTime, 
			String endTime, double extraCost, String member,double total) throws ParseException {
		Reservations res=new Reservations();
		res.setReservation(3,startDate,endDate,startTime,endTime);
		boolean isMember = false;
		if(member.equalsIgnoreCase("yes")) {
			isMember = true;
		}
		assertEquals(booking.calculateInvoice(carName, res, extraCost, isMember),total,0.01);

	}

}
