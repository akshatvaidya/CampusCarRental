package carRental.test;


import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import carRental.model.payment;
import carRental.model.makePaymentErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class paymentTest {

	private payment payment;
	private makePaymentErrorMsgs makePaymentErrorMsgs ;
	
	@Before
	public void setUp() {
		payment = new payment();
		makePaymentErrorMsgs = new makePaymentErrorMsgs();
	}
	
	@Test
	@FileParameters("testCases/payment.csv")
	public void test(int testcaseNumber, String nameOnCard, String cardNumber, String expiryDate, String cvv, 
			String cardType, String nameError, String cardNumberError, String expiryError, String cvvError) 
					throws ParseException {
		payment.setPayment(nameOnCard, cardType, cardNumber, expiryDate, cvv);
		payment.validatePayment(makePaymentErrorMsgs,"");
		
		assertEquals(nameError, makePaymentErrorMsgs.getNameError());
		assertEquals(cardNumberError, makePaymentErrorMsgs.getCardNumberError());
		assertEquals(expiryError, makePaymentErrorMsgs.getDateError());
		assertEquals(cvvError, makePaymentErrorMsgs.getCvvError());
	
	}
}
