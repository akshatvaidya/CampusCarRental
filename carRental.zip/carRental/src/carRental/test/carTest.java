package carRental.test;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import carRental.model.AddCarErrorMsgs;
import carRental.model.Car;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class carTest {

	private Car car;
	private AddCarErrorMsgs carErrorMsgs;
	
	@Before
	public void setUp() {
		car = new Car();
		carErrorMsgs = new AddCarErrorMsgs();
	}
	
	@Test
	@FileParameters("testCases/cars.csv")
	public void test(int testcaseNumber, String carName, String capacity, String weekdayRate, String weekendRate, String weekRate,
			String gps, String siriusXM, String onStar, String carNameError, String weekdayRateError, String weekendRateError,
			String weekRateError, String gpsError, String siriusXMError, String onStarError) throws ParseException {
		
			car.setCar(carName, capacity, weekdayRate, weekendRate, weekRate, gps, siriusXM, onStar);
			car.validateCar(car,carErrorMsgs);
			
			assertEquals(carNameError, carErrorMsgs.getNameError()); 
			assertEquals(weekdayRateError, carErrorMsgs.getWeekDayRateError());
			assertEquals(weekendRateError, carErrorMsgs.getWeekendRateError());
			assertEquals(weekRateError, carErrorMsgs.getWeekRateError());
			assertEquals(gpsError, carErrorMsgs.getGpsRateError());
			assertEquals(siriusXMError, carErrorMsgs.getSiriusXMRateError());
			assertEquals(onStarError, carErrorMsgs.getOnStarRateError());
			
	}

}
