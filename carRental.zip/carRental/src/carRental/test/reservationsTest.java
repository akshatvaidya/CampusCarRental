package carRental.test;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import carRental.model.Reservations;
import carRental.model.requestRentalErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class reservationsTest {

	
	private Reservations reservations;
	private requestRentalErrorMsgs requestRentalErrorMsgs;
	
	@Before
	public void setUp() {
		reservations = new Reservations();
		requestRentalErrorMsgs = new requestRentalErrorMsgs();
	}
	
	@Test
	@FileParameters("testCases/reservations.csv")
	public void test(int testcaseNumber, int occupants, String sdate, String edate, String stime, String etime, 
			String dateError, String timeError, String workingHoursError) throws ParseException {
		
		reservations.setReservation(occupants, sdate, edate, stime, etime);
		reservations.validateReservation(reservations, requestRentalErrorMsgs);
		
		assertEquals(dateError, requestRentalErrorMsgs.getDateError());  
		assertEquals(timeError, requestRentalErrorMsgs.getTimeError());
		assertEquals(workingHoursError, requestRentalErrorMsgs.getInvalidWorkingHoursError());
	}
}
