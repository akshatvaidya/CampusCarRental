package carRental.test;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import carRental.model.SystemUser;
import carRental.model.SystemUserErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class SystemUserTest {

	private SystemUser systemUser;
	private SystemUserErrorMsgs systemUserErrorMsgs;
	
	@Before
	public void setUp() {
		systemUser = new SystemUser();
		systemUserErrorMsgs = new SystemUserErrorMsgs();
	}
	
	@Test
	@FileParameters("testCases/systemUser.csv")
	public void test(int testcaseNumber, String username, String password, String role, String utaid, String 
			firstname, String lastname, String addressline1, String addressline2, String city, String state, 
			String country, String zipcode, String drivinglicense, String licenseexpiry, String issuingcountry, 
			String AACMember, String email, String dateofbirth, String contact, String usernameError, 
			String passwordError, String utaidError, String firstNameError, String lastNameError,
			String aline1Error, String aline2Error, String cityError, String stateError, String countryError, 
			String zipCodeError,String drivingLicenseError, String licenseExpiryError, String icError,
			String emailError, String dobError, String contactError) throws ParseException {
		
			systemUser.setSystemUser(username, password, role, utaid, firstname, lastname, addressline1, 
					addressline2, city, state, country, zipcode, drivinglicense, licenseexpiry, issuingcountry, 
					AACMember, email, dateofbirth, contact);
			systemUser.validateSystemUser(systemUser, systemUserErrorMsgs);
			
			assertEquals(usernameError, systemUserErrorMsgs.getUsernameError()); 
			assertEquals(passwordError, systemUserErrorMsgs.getPasswordError());
			assertEquals(utaidError, systemUserErrorMsgs.getUTAIDError());
			assertEquals(firstNameError, systemUserErrorMsgs.getFirstnameError());
			assertEquals(lastNameError, systemUserErrorMsgs.getLastnameError());
			assertEquals(aline1Error, systemUserErrorMsgs.getAddressline1Error());
			//assertEquals(aline2Error, systemUserErrorMsgs.getAddressline2Error());
			assertEquals(cityError, systemUserErrorMsgs.getCityError());
			assertEquals(stateError, systemUserErrorMsgs.getStateError());
			assertEquals(countryError, systemUserErrorMsgs.getCountryError());
			assertEquals(zipCodeError, systemUserErrorMsgs.getZipcodeError());
			assertEquals(drivingLicenseError, systemUserErrorMsgs.getDrivinglicenseError());
			assertEquals(licenseExpiryError, systemUserErrorMsgs.getLicenseexpiryError());
			assertEquals(icError, systemUserErrorMsgs.getIssuingcountryError());
			assertEquals(emailError, systemUserErrorMsgs.getEmailError());
			assertEquals(dobError, systemUserErrorMsgs.getDateofbirthError());
			assertEquals(contactError, systemUserErrorMsgs.getContactError());
			
	}
}
