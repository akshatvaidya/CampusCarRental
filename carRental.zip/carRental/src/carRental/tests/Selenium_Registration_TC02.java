package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;

public class Selenium_Registration_TC02 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
 
  }

  @Test
  public void testSeleniumTC18() throws Exception {
	driver.get(webAppURL);
	
	driver.findElement(By.xpath(prop.getProperty("Login_Link_SignUp"))).click();
	CR_BF_Registration(driver,"ya","AK", "100","A","V","User", "1994-04","4", "Ap", 
			"M","Mah","7601","Uni","Dl 13","2022-04-26",
			"Ind","Yes", "akshat1@gmail","67543567");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[1]")).getText(),
			"Your username must be between 3 to 45 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[3]")).getText(),
			"Your password must be between 8 to 20 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[4]")).getText(),
			"UTA ID must be of 10 digits only");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[5]")).getText(),
			"Your first name must be between 2 to 45 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[6]")).getText(),
			"Your last name must be between 2 to 45 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[7]")).getText(),
			"Please enter a valid date");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[8]")).getText(),
			"Only 3 to 45 characters allowed");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[9]")).getText(),
			"Only 3 to 45 characters allowed");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[10]")).getText(),
			"City can only be 4 to 45 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[11]")).getText(),
			"Your username must be between 3 to 45 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[13]")).getText(),
			"Country can only be 4 to 45 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[12]")).getText(),
			"Zipcode can only be 5 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[14]")).getText(),
			"License can only be 8 to 20 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[15]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[16]")).getText(),
			"Issuing country name can only be 4 to 45 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[17]")).getText(),
			"Please enter a valid email address");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[18]")).getText(),
			"Contact Number must be of 10 digits only");
	CR_BF_Registration(driver,"Viraj","VirajViraj1!", "1001545989","Akshat","Vaidya","User", "1994-04-26","419 summit avenue", "Apt 202", 
			"Mumbai","Maharashtra","76013","United states","Dl 123212312","2022-04-26",
			"India","Yes", "akshat1@gmail.com","6754356798");
  }
	

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }

}
