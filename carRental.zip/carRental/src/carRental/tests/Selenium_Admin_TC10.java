package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_Admin_TC10 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameA");
    password = prop.getProperty("passwordA");
  }

  @Test
  public void testSeleniumTC01() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("AdminHomePage_Btn_UpdateProfile"))).click();
	
    CR_BF_Updateprofile(driver,"Ak", "100","A","V","1994-04","4","Ap","M", 
    		"Mah","7601","Uni","DL2312","2022-04-26","Ind",
			"Yes","akshat1@gmail", "682123457");
    
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[2]")).getText(),
    		"Your password must be between 8 to 20 characters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[3]")).getText(),
    		"UTA ID must be of 10 digits only");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[4]")).getText(),
    		"Your first name must be between 2 to 45 characters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[5]")).getText(),
    		"Your last name must be between 2 to 45 characters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[16]")).getText(),
    		"Please enter a valid date");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[6]")).getText(),
    		"Only 3 to 45 characters allowed");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[7]")).getText(),
    		"Only 3 to 45 characters allowed");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[8]")).getText(),
    		"City can only be 4 to 45 characters long");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[9]")).getText(),
    		"State can only be 4 to 45 characters long");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[11]")).getText(),
    		"Zipcode can only be 5 characters long");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[10]")).getText(),
    		"Country can only be 4 to 45 characters long");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[12]")).getText(),
    		"License can only be 8 to 20 characters long");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[14]")).getText(),
    		"Issuing country name can only be 4 to 45 characters long");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[13]")).getText(),
			"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[15]")).getText(),
    		"Please enter a valid email address");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[17]")).getText(),
    		"Contact Number must be of 10 digits only");
    
    CR_BF_Updateprofile(driver,"ShubhangiShubhangi1!", "1001550684","Akshat","Vaidya","1994-04-26","419 Summit AVenue","Apt 202","Mumbai", 
    		"Maharashtra","76013","United States","DL 12312312","2022-04-26","United States",
			"Yes","akshatvaidya1@gmail.com", "6825592366");
    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Btn_Update"))).click();
    assertEquals(driver.findElement(By.xpath("html/body/font")).getText(),
			"Profile Updated Successfully..");

    driver.findElement(By.xpath(prop.getProperty("Admin_UpdateProfile_Btn_homepage"))).click();
    driver.findElement(By.xpath(prop.getProperty("AdminHomePage_Btn_logout"))).click();

  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
