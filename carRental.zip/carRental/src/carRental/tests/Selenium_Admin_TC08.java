package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_Admin_TC08 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameA");
    password = prop.getProperty("passwordA");
  }

  @Test
  public void testSeleniumTC01() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("AdminHomePage_Btn_EditUserProfile"))).click();
	driver.findElement(By.xpath(prop.getProperty("EditUserProfile_Txt_Username"))).clear();
    driver.findElement(By.xpath(prop.getProperty("EditUserProfile_Txt_Username"))).sendKeys("Darshan");
	driver.findElement(By.xpath(prop.getProperty("EditUserProfile_Btn_Serch"))).click();
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/font")).getText(),
			"Username does not exist");
	driver.findElement(By.xpath(prop.getProperty("EditUserProfile_Txt_Username"))).clear();
    driver.findElement(By.xpath(prop.getProperty("EditUserProfile_Txt_Username"))).sendKeys("Akshat");
    driver.findElement(By.xpath(prop.getProperty("EditUserProfile_Btn_Serch"))).click();
    CR_BF_Updateprofile(driver,"akshatakshat1!", "qwertyuiop","Akshat","Vaidya","2018","419 Summit Avenue","Apt 202","Mumbai", 
    		"Maharashtra","76013","United States","DL 12312312","2017-1","In123",
			"Yes","sa@", "6821234567");
    
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[2]")).getText(),
    		"Password must contain an uppercase letter\nPassword must contain a number\nPassword must contain a special character");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[3]")).getText(),
			"UTA ID can only contain numbers");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[4]")).getText(),
			"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[5]")).getText(),
			"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[16]")).getText(),
    		"Please enter a valid date");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[6]")).getText(),
    		"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[7]")).getText(),
    		"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[8]")).getText(),
    		"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[9]")).getText(),
    		"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[11]")).getText(),
    		"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[10]")).getText(),
			"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[12]")).getText(),
    		"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[14]")).getText(),
    		"Country can only contain letters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[13]")).getText(),
			"Please enter a valid date");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[15]")).getText(),
    		"Your email ID must be between 7 to 45 characters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[17]")).getText(),
    		"");
    
    CR_BF_Updateprofile(driver,"AkshatAkshat1!", "1001550684","Akshat","Vaidya","1994-04-26","419 Summit AVenue","Apt 202","Mumbai", 
    		"Maharashtra","76013","United States","DL 12312312","2022-04-26","United States",
			"Yes","akshatvaidya1@gmail.com", "6825592366");

    assertEquals(driver.findElement(By.xpath("html/body/font")).getText(),
			"Profile Updated Successfully..");

    driver.findElement(By.xpath(prop.getProperty("EditUserProfile_Btn_homepage"))).click();
    driver.findElement(By.xpath(prop.getProperty("AdminHomePage_Btn_logout"))).click();

  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
