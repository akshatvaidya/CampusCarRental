package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_User_TC06 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("username");
    password = prop.getProperty("password");
  }

  @Test
  public void testSeleniumTC06() throws Exception {

	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_requestRental"))).click();
	CR_BF_SearchCar(driver, "4", "2018-12-15", "2018-12-15", "08:00", "18:00");
	assertEquals(driver.findElement(By.xpath("html/body/form/h2[2]/font")).getText(),
			"Saturday 8am-5pm");
	CR_BF_SearchCar(driver, "3", "2018-11-29", "2018-12-01", "10:00", "13:00");
	driver.findElement(By.xpath("html/body/button")).click();
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
