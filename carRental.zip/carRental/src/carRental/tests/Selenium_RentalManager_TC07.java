package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;

public class Selenium_RentalManager_TC07 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameR");
    password = prop.getProperty("passwordR");
  }

  @Test
  public void testSeleniumTC07() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_searchCars"))).click();
	CR_BF_SearchCar(driver, "3", "2018-11-10", "2018-11-17", "07:00", "21:00");
	assertEquals(driver.findElement(By.xpath("html/body/form/h2[2]/font")).getText(),
			"Saturday 8am-5pm");
	CR_BF_SearchCar(driver, "3", "2019-02-02", "2019-02-05", "13:00", "15:00");
	driver.findElement(By.xpath(prop.getProperty("AvailableCars_Btn_Homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
