package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;

public class Selenium_RentalManager_TC16 extends carRental_BusinessFunctions {
  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameR");
    password = prop.getProperty("passwordR");
  }

  @Test
  public void testSeleniumTC16() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_addCar"))).click();
	CR_BF_AddCar(driver, "Compact", "50.0", "60.0", "70.0", "7.0", "7.0", "7.0", "10.0");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[1]")).getText(),
			"Car name already present");
	CR_BF_AddCar(driver, "Corolla", "4", "50.0", "60.0", "130.0", "7.0", "7.0", "10.0");
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_addCar"))).click();
	CR_BF_AddCar(driver, "Corolla", "4", "50.0", "60.0", "130.0", "7.0", "7.0", "10.0");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[1]")).getText(),
			"Car name already present");
	driver.findElement(By.xpath(prop.getProperty("AddCar_Btn_homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
