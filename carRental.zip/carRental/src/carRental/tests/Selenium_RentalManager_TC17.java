package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;

public class Selenium_RentalManager_TC17 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameR");
    password = prop.getProperty("passwordR");
  }

  @Test
  public void testSeleniumTC17() throws Exception {
  
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_updateprofile"))).click();
	CR_BF_Updateprofile(driver, "Sa", "100", "S", "S", "1994", "4", "A", "A", "T", "7", "U", "DL 123", "2020", "U", "Yes", 
			"sanmit@gmail", "682");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[2]")).getText(),
			"Your password must be between 8 to 20 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[3]")).getText(),
			"UTA ID must be of 10 digits only");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[4]")).getText(),
			"Your first name must be between 2 to 45 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[5]")).getText(),
			"Your last name must be between 2 to 45 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[6]")).getText(),
			"Only 3 to 45 characters allowed");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[7]")).getText(),
			"Only 3 to 45 characters allowed");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[8]")).getText(),
			"City can only be 4 to 45 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[9]")).getText(),
			"State can only be 4 to 45 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[10]")).getText(),
			"Country can only be 4 to 45 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[11]")).getText(),
			"Zipcode can only be 5 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[12]")).getText(),
			"License can only be 8 to 20 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[13]")).getText(),
			"Please enter a valid date");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[14]")).getText(),
			"Issuing country name can only be 4 to 45 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[15]")).getText(),
			"Please enter a valid email address");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[16]")).getText(),
			"Please enter a valid date");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[17]")).getText(),
			"Contact Number must be of 10 digits only");
	CR_BF_Updateprofile(driver, "SanmitSanmit1!", "1001550684", "Sanmit", "Sawant", "1994-01-01", "419 Summit Ave", "Apt 202",
						"Arlington", "Texas", "76013", "United States", "DL 123456789", "2020-01-01", "United States", "Yes", 
						"sanmit@gmail.com", "6825592364");
	assertEquals(driver.findElement(By.xpath("html/body/font")).getText(),
			"Profile Updated Successfully..");
	driver.findElement(By.xpath(prop.getProperty("RentalManager_UpdateProfile_Btn_homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
