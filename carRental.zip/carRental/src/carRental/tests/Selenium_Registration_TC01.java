package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_Registration_TC01 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
  }

  @Test
  public void testSeleniumTC18() throws Exception {

	driver.get(webAppURL);
	
	driver.findElement(By.xpath(prop.getProperty("Login_Link_SignUp"))).click();
	CR_BF_Registration(driver,"Sanmit12$%","Sanmit12$%", "1001545asa","Aksh1","Vaidya1","User", "2019-04-04","AAAAAA", "AAAA", 
			"Mumn123","Mah12344","7601","Uni12 stat","Dl AAAAAAAAA","2016-04-26",
			"Ind123","Yes", "akshat@vai","67543567AA");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[1]")).getText(),
			"Username can only contain letters and numbers");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[3]")).getText(),
			"Your username and password cannot be the same");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[4]")).getText(),
			"UTA ID can only contain numbers");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[5]")).getText(),
			 "First name must only contain letters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[6]")).getText(),
			"Last name must only contain letters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[7]")).getText(),
			"Date of birth cannot be greater than today's date");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[8]")).getText(),
			"Address must contain letters and numbers both");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[9]")).getText(),
			"Address must contain letters and numbers both");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[10]")).getText(),
			"City can only contain letters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[11]")).getText(),
			"Username can only contain letters and numbers");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[13]")).getText(),
			"Country can only contain letters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[12]")).getText(),
			"Zipcode can only be 5 characters long");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[14]")).getText(),
			"License number must contain letters and numbers both");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[15]")).getText(),
			"Driving License should not be expired");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[16]")).getText(),
			"Country can only contain letters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[17]")).getText(),
			"Please enter a valid email address");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[18]")).getText(),
			"Contact number can only contain numbers");
	CR_BF_Registration(driver,"Viraj","VirajViraj1!", "1001545989","Akshat","Vaidya","User", "1994-04-26","419 summit avenue", "Apt 202", 
			"Mumbai","Maharashtra","76013","United states","Dl 123212312","2022-04-26",
			"India","Yes", "akshat1@gmail.com","6754356798");
  }
	
  @After
  public void tearDown() throws Exception {
    driver.quit();

  }

}
