package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;

public class Selenium_RentalManager_TC14 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameR");
    password = prop.getProperty("passwordR");
  }

  @Test
  public void testSeleniumTC14() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_addCar"))).click();
	driver.findElement(By.xpath(prop.getProperty("AddCar_Btn_AddCar"))).click();
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[1]")).getText(),
			"Car name must be between 3 to 45 characters");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[2]")).getText(),
			"Rate can only be a number");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[3]")).getText(),
			"Rate can only be a number");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[4]")).getText(),
			"Rate can only be a number");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[5]")).getText(),
			"Rate can only be a number");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[6]")).getText(),
			"Rate can only be a number");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[7]")).getText(),
			"Rate can only be a number");
	CR_BF_AddCar(driver, "Suzuki", "8", "70.0", "80.0", "150.0", "9.0", "9.0", "12.0");
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_addCar"))).click();
	CR_BF_AddCar(driver, "Suzuki", "4", "50.0", "60.0", "130.0", "7.0", "7.0", "10.0");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[1]")).getText(),
			"Car name already present");
	driver.findElement(By.xpath(prop.getProperty("AddCar_Btn_homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
