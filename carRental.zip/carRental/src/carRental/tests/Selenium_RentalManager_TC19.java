package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;

public class Selenium_RentalManager_TC19 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameR");
    password = prop.getProperty("passwordR");
  }

  @Test
  public void testSeleniumTC19() throws Exception {

	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_updateprofile"))).click();
	CR_BF_Updateprofile(driver, "SanmitSanmit", "1001550684", "Sanmit", "Sawant", "1994-04-26", "419 Summit Ave", "Apt 202", 
			"Arlington", "Texas", "76013", "United States", "DL 1234567", "2019-01-01", "United States", "Yes", 
			"Sanmit@gmail@gmail.com", "6825592364");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[2]")).getText(),
			"Password must contain an uppercase letter\nPassword must contain a number\nPassword must contain a special "
			+ "character");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[3]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[4]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[5]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[6]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[7]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[8]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[9]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[10]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[11]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[12]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[13]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[14]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[15]")).getText(),
			"Email must contain only a single @ character");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[16]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[17]")).getText(),
			"");
	CR_BF_Updateprofile(driver, "SanmitSanmit1!", "1001550684", "Sanmit", "Sawant", "1994-01-01", "419 Summit Ave", "Apt 202",
						"Arlington", "Texas", "76013", "United States", "DL 123456789", "2020-01-01", "United States", "Yes", 
						"sanmit@gmail.com", "6825592364");
	assertEquals(driver.findElement(By.xpath("html/body/font")).getText(),
			"Profile Updated Successfully..");
	driver.findElement(By.xpath(prop.getProperty("RentalManager_UpdateProfile_Btn_homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("RMHomepage_Btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
