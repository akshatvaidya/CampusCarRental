package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_User_TC21 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("username");
    password = prop.getProperty("password");
  }

  @Test
  public void testSeleniumTC21() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_updateProfile"))).click();
	CR_BF_Updateprofile(driver, "SanmitSanmit1!", "1001550670", "Sanmit", "Sanmit", "2011-01-01", "419 summit ave", "apt 202", "Arlington", 
			"Texas", "76013", "United States", "DL 27184932", "2020-01-01","United States", "yes", "SanmitSawant@gmail.coom", "6825592539");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[2]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[3]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[4]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[5]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[6]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[7]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[8]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[9]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[10]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[11]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[12]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[13]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[14]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[15]")).getText(),
			"Check email extension");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[16]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[17]")).getText(),
			"");
	CR_BF_Updateprofile(driver, "AkshatAkshat1!", "1001550684", "Akshat", "Vaidya", "1994-04-06", "419 Summit ave", "Apt 202", "arlington", "texas", "76013", "United states", "DL 12312123", "2022-04-26",
			"India", "yes", "akshat1@gmail.com", "6824141494");
	assertEquals(driver.findElement(By.xpath("html/body/font")).getText(),
			"Profile Updated Successfully..");
	driver.findElement(By.xpath(prop.getProperty("User_UpdateProfile_Btn_homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_logout"))).click();
  }
	
	
	
  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
