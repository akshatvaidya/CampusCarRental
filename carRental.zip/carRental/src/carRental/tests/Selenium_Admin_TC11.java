package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_Admin_TC11 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("usernameA");
    password = prop.getProperty("passwordA");
  }

  @Test
  public void testSeleniumTC01() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("AdminHomePage_Btn_UpdateProfile"))).click();
	
    CR_BF_Updateprofile(driver,"Shubhangi", "1001535797","Akshat","Vaidya","2018-12-28","419","Apt","1234sa", 
    		"1234sa","San12","1247kak","DLwirjhgry","2017-12-12","In",
			"Yes","akshat1@", "68240827ki");
    
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[2]")).getText(),
			"Your username and password cannot be the same");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[3]")).getText(),
			"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[4]")).getText(),
			"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[5]")).getText(),
			"");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[16]")).getText(),
    		"Date of birth cannot be greater than today's date");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[6]")).getText(),
    		"Address must contain letters and numbers both");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[7]")).getText(),
    		"Address must contain letters and numbers both");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[8]")).getText(),
    		"City can only contain letters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[9]")).getText(),
    		"State can only contain letters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[11]")).getText(),
    		"Zipcode can only contain numbers");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[10]")).getText(),
			"Country can only contain letters");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[12]")).getText(),
    		"License number must contain letters and numbers both");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[14]")).getText(),
			"Issuing country name can only be 4 to 45 characters long");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[15]")).getText(),
    		"Please enter a valid email address");
    assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[17]")).getText(),
    		"Contact number can only contain numbers");
     
    
    CR_BF_Updateprofile(driver,"ShubhangiShubhangi1!", "1001550684","Akshat","Vaidya","1994-04-26","419 Summit AVenue","Apt 202","Mumbai", 
    		"Maharashtra","76013","United States","DL 12312312","2022-04-26","United States",
			"Yes","akshatvaidya1@gmail.com", "6825592366");
    driver.findElement(By.xpath(prop.getProperty("UpdateProfile_Btn_Update"))).click();
    assertEquals(driver.findElement(By.xpath("html/body/font")).getText(),
			"Profile Updated Successfully..");

    driver.findElement(By.xpath(prop.getProperty("Admin_UpdateProfile_Btn_homepage"))).click();
    driver.findElement(By.xpath(prop.getProperty("AdminHomePage_Btn_logout"))).click();

  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
