package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_User_TC02 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("username");
    password = prop.getProperty("password");
  }

  @Test
  public void testSeleniumTC02() throws Exception {

	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_requestRental"))).click();
	CR_BF_SearchCar(driver, "", "", "", "", "");
	assertEquals(driver.findElement(By.xpath("html/body/form/font[1]")).getText(),
			"Please fill out this field");
	assertEquals(driver.findElement(By.xpath("html/body/form/font[2]")).getText(),
			"Please fill out this field");
	assertEquals(driver.findElement(By.xpath("html/body/form/font[3]")).getText(),
			"Please fill out this field");
	assertEquals(driver.findElement(By.xpath("html/body/form/font[4]")).getText(),
			"Please fill out this field");
	CR_BF_SearchCar(driver, "3", "2018-11-29", "2018-12-01", "10:00", "13:00");
	driver.findElement(By.xpath("html/body/button")).click();
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
