package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;


public class Selenium_Registration_TC04 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
  }

  @Test
  public void testSeleniumTC18() throws Exception {
	driver.get(webAppURL);
	
	driver.findElement(By.xpath(prop.getProperty("Login_Link_SignUp"))).click();
	CR_BF_Registration(driver,"Tejasvini","SanmitSanmit1!", "1001535797","Akshat","Vaidya","User", "1994-04-26","419 summit avenue", "Apt 202", 
			"Mumbai","Maharsahtra","76013","Unites states","Dl 76766513","2022-04-26",
			"India","Yes", "Sanmit@gmail.coom","5643564545");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[1]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[3]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[4]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[5]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[6]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div/font[7]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[8]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[9]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[10]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[11]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[13]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[12]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[14]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[15]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[16]")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[17]")).getText(),
			"Check email extension");
	assertEquals(driver.findElement(By.xpath("html/body/form/div[1]/font[18]")).getText(),
			"");
	CR_BF_Registration(driver,"Viraj","VirajViraj1!", "1001545989","Akshat","Vaidya","User", "1994-04-26","419 summit avenue", "Apt 202", 
			"Mumbai","Maharashtra","76013","United states","Dl 123212312","2022-04-26",
			"India","Yes", "akshat1@gmail.com","6754356798");

  }
	
	
	
  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
