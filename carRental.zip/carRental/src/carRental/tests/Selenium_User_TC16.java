package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;
import carRental.model.Reservations;
import carRental.model.booking;


public class Selenium_User_TC16 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("username");
    password = prop.getProperty("password");
  }

  @Test
  public void testSeleniumTC16() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_requestRental"))).click();
	CR_BF_SearchCar(driver, "3", "2021-08-23", "2021-08-30", "09:00", "09:00");
	driver.findElement(By.xpath("html/body/div[1]/div/form/input[2]")).click();
	driver.findElement(By.xpath("html/body/div[1]/div/form/input[3]")).click();
	driver.findElement(By.xpath("html/body/div[1]/div/form/input[5]")).click();
	driver.findElement(By.xpath("html/body/div[1]/div/form/input[6]")).click();
	driver.findElement(By.xpath(prop.getProperty("ConfirmCar_Btn_proceed"))).click();
	CR_BF_makepayment(driver,"Rachana","American Express","423456789012786","01","2019","3569");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[1]/div[1]/font")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[3]/div[1]/font")).getText(),
			"American Express card number should start with 37");
	assertEquals(driver.findElement(By.xpath(".//*[@id='expiration-date']/font")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[5]/div[1]/font")).getText(),
			"");
	CR_BF_makepayment(driver,"Rachana","American Express","370155068400000","08","2022","1234");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[6]/font")).getText(),
			"Payment was successful");
	driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Btn_homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_viewRentals"))).click();
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[2]")).getText(),
			"No of Occupants : 3");
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[3]")).getText(),
			"Start Date: 2021-08-23");
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[4]")).getText(),
			"End Date: 2021-08-30");
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[5]")).getText(),
			"Start Time: 09:00:00");
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[6]")).getText(),
			"End Time: 09:00:00");
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[7]")).getText(),
			"GPS: yes");
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[8]")).getText(),
			"Onstar: yes");
	assertEquals(driver.findElement(By.xpath("html/body/div[6]/div/form/h3[9]")).getText(),
			"SiriusXM: no");
	String carName = driver.findElement(By.xpath("html/body/div[6]/div/h2/font")).getText();
	String temp = "";
	temp = driver.findElement(By.xpath("html/body/div[6]/div/form/h3[2]")).getText();
	String occupants = temp.replace("No of Occupants : ", "");

	temp = driver.findElement(By.xpath("html/body/div[6]/div/form/h3[3]")).getText();
	String sdate = temp.replace("Start Date: ", "");

	temp = driver.findElement(By.xpath("html/body/div[6]/div/form/h3[4]")).getText();
	String edate = temp.replace("End Date: ", "");
	
	temp = driver.findElement(By.xpath("html/body/div[6]/div/form/h3[5]")).getText();
	String temp2 = temp.replace("Start Time: ", "");
	String stime = temp2.replace("09:00:00", "09:00");
	
	temp = driver.findElement(By.xpath("html/body/div[6]/div/form/h3[6]")).getText();
	temp2 = temp.replace("End Time: ", "");
	String etime = temp2.replace("09:00:00", "09:00");

	Reservations reservation = new Reservations();
	reservation.setReservation(Integer.parseInt(occupants), sdate, edate, stime, etime);
	booking booking = new booking();
	double totalCost = booking.calculateInvoice(carName, reservation, 14.0d, true);
	
	driver.findElement(By.xpath(prop.getProperty("ViewRentals_Btn_Homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
