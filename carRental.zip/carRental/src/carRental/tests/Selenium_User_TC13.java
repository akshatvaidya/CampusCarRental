package carRental.tests;


import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import carRental.functions.carRental_BusinessFunctions;
import carRental.model.Reservations;
import carRental.model.booking;


public class Selenium_User_TC13 extends carRental_BusinessFunctions {

  public static String webAppURL,webSharedUIMapPath, username, password;


  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/CR_Configuration.properties"));
    webAppURL = prop.getProperty("webAppURL");
    webSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(webSharedUIMapPath));
    username = prop.getProperty("username");
    password = prop.getProperty("password");
  }

  @Test
  public void testSeleniumTC13() throws Exception {
	driver.get(webAppURL);
	CR_BF_Login(driver,username, password);
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_requestRental"))).click();
	CR_BF_SearchCar(driver, "4", "2021-01-03", "2021-01-06", "12:00", "15:00");
	driver.findElement(By.xpath("html/body/div[4]/div/form/input[6]")).click();
	driver.findElement(By.xpath(prop.getProperty("ConfirmCar_Btn_proceed"))).click();
	CR_BF_makepayment(driver,"Rachana Badekar","Visa","1234567890123458","01","2019","356");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[1]/div[1]/font")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[3]/div[1]/font")).getText(),
			"Visa card number should start with a 4");
	assertEquals(driver.findElement(By.xpath(".//*[@id='expiration-date']/font")).getText(),
			"");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[5]/div[1]/font")).getText(),
			"");
	CR_BF_makepayment(driver,"Rachana","Visa","4001550684000000","08","2020","123");
	assertEquals(driver.findElement(By.xpath("html/body/div[1]/form/div[6]/font")).getText(),
			"Payment was successful");
	driver.findElement(By.xpath(prop.getProperty("PaymentConfirmation_Btn_homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_viewRentals"))).click();
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[2]")).getText(),
			"No of Occupants : 4");
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[3]")).getText(),
			"Start Date: 2021-01-03");
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[4]")).getText(),
			"End Date: 2021-01-06");
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[5]")).getText(),
			"Start Time: 12:00:00");
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[6]")).getText(),
			"End Time: 15:00:00");
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[7]")).getText(),
			"GPS: no");
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[8]")).getText(),
			"Onstar: no");
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[9]")).getText(),
			"SiriusXM: no");
	String carName = driver.findElement(By.xpath("html/body/div[3]/div/h2/font")).getText();
	String temp = "";
	temp = driver.findElement(By.xpath("html/body/div[3]/div/form/h3[2]")).getText();
	String occupants = temp.replace("No of Occupants : ", "");

	temp = driver.findElement(By.xpath("html/body/div[3]/div/form/h3[3]")).getText();
	String sdate = temp.replace("Start Date: ", "");

	temp = driver.findElement(By.xpath("html/body/div[3]/div/form/h3[4]")).getText();
	String edate = temp.replace("End Date: ", "");
	
	temp = driver.findElement(By.xpath("html/body/div[3]/div/form/h3[5]")).getText();
	String temp2 = temp.replace("Start Time: ", "");
	String stime = temp2.replace("12:00:00", "12:00");
	
	temp = driver.findElement(By.xpath("html/body/div[3]/div/form/h3[6]")).getText();
	temp2 = temp.replace("End Time: ", "");
	String etime = temp2.replace("15:00:00", "15:00");

	Reservations reservation = new Reservations();
	reservation.setReservation(Integer.parseInt(occupants), sdate, edate, stime, etime);
	booking booking = new booking();
	double totalCost = booking.calculateInvoice(carName, reservation, 0.0d, true);
	
	assertEquals(driver.findElement(By.xpath("html/body/div[3]/div/form/h3[10]")).getText(),
			"Total Cost: " + totalCost);
	driver.findElement(By.xpath(prop.getProperty("ViewRentals_Btn_Homepage"))).click();
	driver.findElement(By.xpath(prop.getProperty("UserHome_btn_logout"))).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
  }
}
