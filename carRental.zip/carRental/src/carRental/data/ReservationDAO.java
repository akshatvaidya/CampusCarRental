package carRental.data;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import carRental.model.BookedReservations;
import carRental.model.Car;
import carRental.model.Reservations;
import carRental.model.dbconnection;

public class ReservationDAO {
	
	static dbconnection DBMgr = dbconnection.getInstance();

	/*public String reservationErrors(int capacity, String startDate2, String endDate2, String startTime2,
			String endTime2) {

		Connection conn = null;  
		String result = "";
		try {   
			conn = dbconnection.getDBConnection();  
			
			Date sdate = Date.valueOf(startDate2);
			Date edate = Date.valueOf(endDate2);
			
			startTime2 += ":00";
			endTime2 += ":00";
			Time stime = Time.valueOf(startTime2);
			Time etime = Time.valueOf(endTime2);
			
			//check capacity cars select * from cars where '5' <= capacity;
			PreparedStatement ps=null;
			ResultSet rs=null;
			String query="select * from cars where ? <= capacity";
			ps=conn.prepareStatement(query);
			ps.setInt(1, capacity);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				PreparedStatement p1 = null;
				ResultSet rs1 = null;
				
				//select c.* from cars c left join reservations r on c.carName like r.car where r.reservationID is null AND c.capacity >= 6;
				
				String query1 = "select distinct c.* from cars c left join reservations r on c.carName "
						+ "like r.car where r.reservationID is null AND c.capacity >= ?";
				p1 = conn.prepareStatement(query1);
				p1.setInt(1, capacity);
				rs1 = p1.executeQuery();
				int i = 0;
				while(rs1.next()) {
					carsGoodForDisplay.add(rs1.getString(1));
					i++;
				}	
				PreparedStatement p2 = null;
				ResultSet rs2 = null;
				
				String query2 = "select r.* from cars c left join reservations r on c.carName "
						+ "like r.car where r.reservationID is not null AND c.capacity >= ?";
				
				p2 = conn.prepareStatement(query2);
				ps.setInt(1, capacity);
				rs2 = p2.executeQuery();
				
				while(rs2.next()) {
					String car = rs2.getString(3);
					if(carsGoodForDisplay.contains(car)) {
						Date s = rs2.getDate(5);
						Date e = rs2.getDate(6);
						Time p = rs2.getTime(7);
						Time d = rs2.getTime(8);
						
						if((sdate.before(s)) && edate.before(s)) {
							carsGoodForDisplay.add(car);
						}
						else if((sdate.after(e)) && edate.after(e)) {
							carsGoodForDisplay.add(car);
						}
						else if((sdate.compareTo(s) == 0) && (edate.compareTo(s) == 0)) {
							if((stime.before(p)) && etime.before(d)) {
								carsGoodForDisplay.add(car);
							}
						}
						else if((sdate.compareTo(e) == 0) && (edate.compareTo(e) == 0)) {
							if((stime.after(d)) && etime.after(d)) {
								carsGoodForDisplay.add(car);
							}
						}
						else if((sdate.before(s)) && edate.compareTo(s) == 0) {
							if((etime.before(p))) {
								carsGoodForDisplay.add(car);				
							}
						}
						else if((sdate.compareTo(e)) == 0 && edate.after(e)) {
							if((stime.after(d))) {
								carsGoodForDisplay.add(car);
							}
						}
						else {
							result = "Please choose different dates";
							
						}

					}
				}
			}
		} catch (SQLException e) {
			System.out.println("bcbbccbc");
			e.printStackTrace();
		}
		return carsGoodForDisplay;	
	}
*/
	public static ArrayList<Car> searchCars(Reservations reservations) {
		
		Connection conn = null;
		ArrayList<Car> availableCars = new ArrayList<Car>();
		try {   
			conn = dbconnection.getDBConnection();  
	
			PreparedStatement p1 = null;
			ResultSet rs1 = null;
			System.out.println(reservations.getNoOfOccupants());
			String query1 = "select distinct c.* from cars c left join reservations r on c.carName "
				+ "like r.car where r.reservationID is null AND c.capacity >= ?";
			p1 = conn.prepareStatement(query1);
			p1.setInt(1, reservations.getNoOfOccupants());
			//System.out.println(reservations.getNoOfOccupants());
			rs1 = p1.executeQuery();
			
			while(rs1.next()) {
				Car car = new Car();
				car.setCarName(rs1.getString(1));
				car.setCapacity(Integer.toString(rs1.getInt(2)));
				car.setWeekdayRate(Double.toString(rs1.getDouble(3)));
				car.setWeekendRate(Double.toString(rs1.getDouble(4)));
				car.setWeekRate(Double.toString(rs1.getDouble(5)));
				car.setGps(Double.toString(rs1.getDouble(6)));
				car.setOnStar(Double.toString(rs1.getDouble(7)));
				car.setSiriusXM(Double.toString(rs1.getDouble(8)));
				availableCars.add(car);	
			}
			PreparedStatement p2 = null;
			ResultSet rs2 = null;
		
			//select * from reservations where '4' <= NoOfOccupants;
			String query2 = "select * from reservations where  ? <= NoOfOccupants";
			p2 = conn.prepareStatement(query2);
			p2.setInt(1, reservations.getNoOfOccupants());
			rs2 = p2.executeQuery();
			ArrayList<String> carsTobeAdded = new ArrayList<String>();
			while(rs2.next()) {
				//String username = rs2.getString(2);
				String carName = rs2.getString(3);
				//int cap = rs2.getInt(4);
				Date sdate = rs2.getDate(5);
				Date edate = rs2.getDate(6);
				Time stime = rs2.getTime(7);
				Time etime = rs2.getTime(8);

				/*System.out.println("--------------------------");
				System.out.println(sdate.toString());
				System.out.println(edate.toString());
				System.out.println(stime.toString());
				System.out.println(etime.toString());*/
				
				
				Date rsdate = Date.valueOf(reservations.getStartDate());
				//System.out.println("1");
				Date redate = Date.valueOf(reservations.getEndDate());
				//System.out.println("2");
				String abc = reservations.getStartTime();
				abc += ":00";
				String xyz = reservations.getEndTime();
				xyz+= ":00";
				Time rstime = Time.valueOf(abc);

				Time retime = Time.valueOf(xyz);

				
				if((rsdate.before(sdate)) && redate.before(sdate)) {
					if(!carsTobeAdded.contains(carName)) {
						carsTobeAdded.add(carName);
					}
				}
				else if((rsdate.after(edate)) && redate.after(edate)) {
					if(!carsTobeAdded.contains(carName)) {
						carsTobeAdded.add(carName);
					}
				}
				else if((rsdate.compareTo(sdate) == 0) && (redate.compareTo(sdate) == 0)) {
					if((rstime.before(stime)) && retime.before(stime)) {
						if(!carsTobeAdded.contains(carName)) {
							carsTobeAdded.add(carName);
						}
					}
				}
				else if((rsdate.compareTo(edate) == 0) && (redate.compareTo(edate) == 0)) {
					if((rstime.after(etime)) && retime.after(etime)) {
						if(!carsTobeAdded.contains(carName)) {
							carsTobeAdded.add(carName);
						}
					}
				}
				else if((rsdate.before(sdate)) && redate.compareTo(sdate) == 0) {
					if((retime.before(stime))) {
						if(!carsTobeAdded.contains(carName)) {
							carsTobeAdded.add(carName);
						}				
					}
				}
				else if((rsdate.compareTo(edate)) == 0 && redate.after(edate)) {
					if((rstime.after(etime))) {
						if(!carsTobeAdded.contains(carName)) {
							carsTobeAdded.add(carName);
						}
					}
				}		
			}
			for(String car:carsTobeAdded) {
				System.out.println(car);
			}
			if(!carsTobeAdded.isEmpty()) {
				PreparedStatement p = null;
				ResultSet rs = null;
				for(String carname: carsTobeAdded) {
					p = null;
					rs = null;

					String query = "select * from cars where carName = ?";
					p = conn.prepareStatement(query);
					p.setString(1, carname);
					rs = p.executeQuery();
					
					while(rs.next()) {
						Car car = new Car();
						car.setCarName(rs.getString(1));
						car.setCapacity(Integer.toString(rs.getInt(2)));
						car.setWeekdayRate(Double.toString(rs.getDouble(3)));
						car.setWeekendRate(Double.toString(rs.getDouble(4)));
						car.setWeekRate(Double.toString(rs.getDouble(5)));
						car.setGps(Double.toString(rs.getDouble(6)));
						car.setOnStar(Double.toString(rs.getDouble(7)));
						car.setSiriusXM(Double.toString(rs.getDouble(8)));
						availableCars.add(car);	
					}			
				}
			}
	}
		catch(Exception e) {
		}
		return availableCars;
	}

	public static void addReservation(String username, Reservations reservation, double totalCost, ArrayList<String> extrasss, 
			String carSelected) throws SQLException {

		PreparedStatement p = null;
		Statement stmt = null;   
		Connection conn = dbconnection.getDBConnection();  
		String g = "no";
		String o = "no";
		String s = "no";
		if(!extrasss.isEmpty()) {
			for(String feature:extrasss) {
				if(feature.equalsIgnoreCase("GPS")) {
					g = "yes";
				
				}
				else if(feature.equalsIgnoreCase("Onstar")) {
					o = "yes";
				}
				else if(feature.equalsIgnoreCase("SiriusXM")) {
					s = "yes";
				}
			}
		}	
		String checkUser = "Select * FROM reservations where username = ?";
		p = conn.prepareStatement(checkUser);
		p.setString(1, username);
		
		String insertSystemUser = "INSERT INTO reservations (username,car,NoOfOccupants,startDate,endDate,startTime,endTime,GPS,"
				+ "Onstar,SiriusXM,totalCost)";					
		insertSystemUser += " VALUES ('"  
				+ username  + "','"
				+ carSelected + "','"
				+ reservation.getNoOfOccupants() + "','"		
				+ reservation.getStartDate() + "','"
				+ reservation.getEndDate() + "','" 
				+ reservation.getStartTime() + "','"
				+ reservation.getEndTime() + "','"
				+ g + "','"
				+ o + "','"
				+ s + "','"
				+ totalCost + "')";
		try { 
		BookedReservations rb = new BookedReservations();
		rb.setReservation(username, carSelected, reservation.getNoOfOccupants(), reservation.getStartDate(),
				reservation.getEndDate(), reservation.getStartTime(), reservation.getEndTime(), g, o, s, totalCost);
		conn = dbconnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = (Statement) conn.createStatement();
		stmt.executeUpdate(insertSystemUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} finally {
		try {
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		};
	}
	}

	public boolean deleteRental(int rid) {
		boolean isDeleted = false;
		
		Connection conn = null;
		Statement stmt = null;  
		int deleted;

		try {   
			String query = "delete from reservations where reservationID = " + rid +";";
			
			conn = dbconnection.getDBConnection();  
			conn.setAutoCommit(false);   
			stmt = (Statement) conn.createStatement();
			deleted = stmt.executeUpdate(query);
			conn.commit();	
		
			//String query1 = "delete from reservations where reservationID = ?";
			//p1 = conn.prepareStatement(query);
			//p1.setInt(1, rid);
			if(deleted == 1) {
				System.out.println(deleted);
				isDeleted = true;
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return isDeleted;
	}

	public ArrayList<BookedReservations> getReservations(String month, String year) {
		Connection conn = null;
		String searchQuery = year+"-"+month;
		ArrayList<BookedReservations> reservations = new ArrayList<BookedReservations>();
		try {   
			conn = dbconnection.getDBConnection();  
	
			PreparedStatement p1 = null;
			ResultSet rs1 = null;
		
			String query1 = "select * from reservations";
			p1 = conn.prepareStatement(query1);
			rs1 = p1.executeQuery();
			
			while(rs1.next()) {
				String sdate = rs1.getDate(5).toString();
				String edate = rs1.getDate(6).toString();
				if(sdate.contains(searchQuery) || edate.contains(searchQuery)) {
					BookedReservations br = new BookedReservations();
					br.setReservationID(rs1.getInt(1));
					br.setUsername(rs1.getString(2));
					br.setCarSelected(rs1.getString(3));
					br.setNoOfOccupants(rs1.getInt(4));
					br.setStartDate(rs1.getDate(5).toString());
					br.setEndDate(rs1.getDate(6).toString());
					br.setStartTime(rs1.getTime(7).toString());
					br.setEndTime(rs1.getTime(8).toString());
					br.setGps(rs1.getString(9));
					br.setOnstar(rs1.getString(10));
					br.setSiriusxm(rs1.getString(11));
					br.setCost(rs1.getDouble(12));
					
					reservations.add(br);
				}
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return reservations;
	}
}
