package carRental.data;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

import carRental.model.dbconnection;

public class AdminDAO {
	static dbconnection DBMgr = dbconnection.getInstance();
	public boolean checkUsername(String username) {
	
		boolean flag=false;

		Connection conn = null;  
		try {   
			conn = dbconnection.getDBConnection();  

			//Exclusive dates
			PreparedStatement ps=null;
			ResultSet rs=null;
			//String query="select * from reservations where ((? < startDate AND ? < startDate) OR (? > endDate AND ? > endDate))";
			String query="select * from registration where username=?";
			ps=conn.prepareStatement(query);
			ps.setString(1, username);
			
			rs=ps.executeQuery();
			

			if (rs.first()) {
				System.out.println("value milali");
				flag = true;
			} 
			else{
				System.out.println("value nahi milali");
			}
		}
			catch (SQLException e) {
				System.out.println("bcbbccbc");
				e.printStackTrace();
			}
		
		return flag;
	}
	public void revokeUser(String username) {

		Statement stmt = null;   
		Connection conn = null; 
				conn = dbconnection.getDBConnection();  
				String query = "INSERT INTO revoked (username) ";					
				query += " VALUES ('"  + username + "')";
				
				try {   
					conn = dbconnection.getDBConnection();  
					conn.setAutoCommit(false);   
					stmt = (Statement) conn.createStatement();
					stmt.executeUpdate(query);
					conn.commit();					 
				} catch (SQLException sqle) { 
					sqle.printStackTrace();
				} finally {
					try {
						conn.close();
						stmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					};
				}
	}
	
	public boolean checkIfRevoked(String username) {
		Statement stmt = null;   
		Connection conn = null;  
		boolean isRevoked = false;
		System.out.println(username);

		try {   
			conn = dbconnection.getDBConnection();  
			stmt = (Statement) conn.createStatement();
			String query = " SELECT * from revoked WHERE username = '"+username+"'";
			ResultSet revoked = stmt.executeQuery(query);
			
			if(revoked.first()) {
				isRevoked = true;
				}
			}
			catch (Exception e){
				System.out.println(e);
			}
		System.out.println(isRevoked);	
		return isRevoked;
	}
	
	
	/*public ArrayList<String> getValues(String username) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		ArrayList<String> details = new ArrayList<String>();
		Connection conn = null; 
		try{			
			conn = dbconnection.getDBConnection();  
			if(conn!=null){
				System.out.println("array list madhe");
				PreparedStatement ps=null;
				ResultSet rs=null;
				String query="select * from rentacar.registration where username=?";
				ps=conn.prepareStatement(query);
				ps.setString(1, username);
				rs=ps.executeQuery();
			
				if(rs==null) {
					System.out.println("null ahe list");

				details =  null;
				}
				else {	
					System.out.println("null nahiye list");

					while(rs.next()){
						System.out.println("while madhe");
						details.add(rs.getString(1));
						details.add(rs.getString(2));
						details.add(rs.getString(3));
						details.add(rs.getString(4));
						details.add(rs.getString(5));
						details.add(rs.getString(6));
						details.add(rs.getString(7));
						details.add(rs.getString(8));
						details.add(rs.getString(9));
						details.add(rs.getString(10));
						details.add(rs.getString(11));
						details.add(rs.getString(12));
						details.add(rs.getString(13));
						details.add(rs.getString(14));
						details.add(rs.getString(15));
						details.add(rs.getString(16));
						details.add(rs.getString(17));
						details.add(rs.getString(18));
						details.add(rs.getString(19));
						
					}
					
						System.out.println("details length:"+details.size());
					
				}
			}
			if(conn!=null){
				conn.close();
			}	
		}
		catch (SQLException e) {
			System.out.print("Not Connected to database");			
		}
		return details;
	}
*/	
  
	}

