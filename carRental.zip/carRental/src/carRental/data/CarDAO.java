package carRental.data;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import carRental.model.dbconnection;

public class CarDAO {
	
	static dbconnection DBMgr = dbconnection.getInstance();

	public static ArrayList<String> getCarDetails(String selectedCar) {
		ArrayList<String> details = new ArrayList<String>();
		System.out.println(selectedCar);
		try{			
			Connection conn = dbconnection.getDBConnection(); 
			if(conn!=null){
				PreparedStatement ps=null;
				ResultSet rs=null;
				String query="select * from cars where carName = ?";
				ps=conn.prepareStatement(query);
				ps.setString(1, selectedCar);
				rs=ps.executeQuery();

				if(rs == null) {
					details =  null;
					}
					else {	
						while(rs.next()){
							details.add(rs.getString(1));
							details.add(rs.getString(2));
							details.add(rs.getString(3));
							details.add(rs.getString(4));
							details.add(rs.getString(5));
							details.add(rs.getString(6));
							details.add(rs.getString(7));
							details.add(rs.getString(8));
						}
					}
				}
				if(conn!=null){
					conn.close();
				}	
			}
			catch (SQLException e) {
				System.out.print("Not Connected to database");			
			}
			return details;
	}
}
