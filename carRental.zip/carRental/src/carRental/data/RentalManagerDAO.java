package carRental.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.annotation.WebServlet;
import com.mysql.jdbc.Statement;

import carRental.model.Car;
import carRental.model.dbconnection;


@WebServlet("/RentalManagerDAO")
public class RentalManagerDAO {
	static dbconnection DBMgr = dbconnection.getInstance();

	public boolean carExistsOrNot(String car) {
		boolean flag = false;
 
		Connection conn = null;  
		try {   
			conn = dbconnection.getDBConnection();  
			
			//Exclusive dates
			PreparedStatement ps=null;
			ResultSet rs=null;
			//String query="select * from reservations where ((? < startDate AND ? < startDate) OR (? > endDate AND ? > endDate))";
			String query="select * from cars where carName=?";
			ps=conn.prepareStatement(query);
			ps.setString(1, car);
			
			rs=ps.executeQuery();
			

			if (rs.next()) {
				flag = true;
				System.out.println("car is "+rs.getString(0).toString());
			} 
       
 

		}
		catch (Exception e){
			
		}
		return flag;
		
}

	public void insertCar(String car, String occ, String weekdayrate, String weekendrate, String weekrate, String gps, String onstar, String siriuxXM) {
		
		Statement stmt = null;   
		Connection conn = dbconnection.getDBConnection();  
		String insertSystemUser = "INSERT INTO cars (carName,capacity,weekDayRate,weekendRate,WeekRate,GPSPerDayRate,OnStarPerDayRate,SiriusXMPerDayRate)";
									
		insertSystemUser += " VALUES ('"  
				+ car  + "','"
				+ occ + "','"
				+ weekdayrate + "','"		
				+ weekendrate + "','"
				+ weekrate + "','" 
				+ gps + "','"
				+ onstar + "','"
				+ siriuxXM + "')";
		try {   
		conn = dbconnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = (Statement) conn.createStatement();
		stmt.executeUpdate(insertSystemUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} //finally {
//		try {
//			conn.close();
//			stmt.close();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}
	}

	public void addCar(Car car) {
		Statement stmt = null;   
		Connection conn = dbconnection.getDBConnection();  
		String insertSystemUser = "INSERT INTO cars (carName,capacity,weekDayRate,weekendRate,WeekRate,GPSPerDayRate,OnStarPerDayRate,SiriusXMPerDayRate)";
									
		insertSystemUser += " VALUES ('"  
				+ car.getCarName()  + "','"
				+ car.getCapacity() + "','"
				+ car.getWeekdayRate() + "','"		
				+ car.getWeekendRate() + "','"
				+ car.getWeekRate() + "','" 
				+ car.getGps() + "','"
				+ car.getOnStar() + "','"
				+ car.getSiriusXM() + "')";
		try {   
		conn = dbconnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = (Statement) conn.createStatement();
		stmt.executeUpdate(insertSystemUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	}
		
	}
}


	
	