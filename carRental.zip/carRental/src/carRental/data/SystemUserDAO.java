package carRental.data;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import carRental.model.BookedReservations;
import carRental.model.SystemUser;
import carRental.model.dbconnection;

public class SystemUserDAO {
	
	static dbconnection DBMgr = dbconnection.getInstance();
	
	public static ArrayList<String> getSystemUser(String username2) {
		ArrayList<String> details = new ArrayList<String>();
		try{			
			Connection conn = dbconnection.getDBConnection(); 
			if(conn!=null){
				PreparedStatement ps=null;
				ResultSet rs=null;
				String query="select * from rentacar.registration where username=?";
				ps=conn.prepareStatement(query);
				ps.setString(1, username2);
				rs=ps.executeQuery();
			
				if(rs == null) {
				details =  null;
				}
				else {	
					while(rs.next()){
						details.add(rs.getString(1));
						details.add(rs.getString(2));
						details.add(rs.getString(3));
						details.add(rs.getString(4));
						details.add(rs.getString(5));
						details.add(rs.getString(6));
						details.add(rs.getString(7));
						details.add(rs.getString(8));
						details.add(rs.getString(9));
						details.add(rs.getString(10));
						details.add(rs.getString(11));
						details.add(rs.getString(12));
						details.add(rs.getString(13));
						details.add(rs.getString(14));
						details.add(rs.getString(15));
						details.add(rs.getString(16));
						details.add(rs.getString(17));
						details.add(rs.getString(18));
						details.add(rs.getString(19));
					}
				}
			}
			if(conn!=null){
				conn.close();
			}	
		}
		catch (SQLException e) {
			System.out.print("Not Connected to database");			
		}
		return details;
	}


	public static void insertSystemUser(SystemUser systemuser) {
		Statement stmt = null;   
		Connection conn = dbconnection.getDBConnection();  
		String insertSystemUser = "INSERT INTO registration (username,password,role,UTAID,firstname,lastname,addressline1,addressline2,"
				+ "city,state,country,zipcode,drivinglicense,licenseexpiry,issuingcountry,AACmember,email,dateofbirth,contact) ";					
		insertSystemUser += " VALUES ('"  
				+ systemuser.getUsername()  + "','"
				+ systemuser.getPassword() + "','"
				+ systemuser.getRole() + "','"		
				+ new BigInteger(systemuser.getUTAID()) + "','"
				+ systemuser.getFirstname() + "','" 
				+ systemuser.getLastname() + "','"
				+ systemuser.getAddressline1() + "','"
				+ systemuser.getAddressline2() + "','"
				+ systemuser.getCity() + "','"
				+ systemuser.getState() + "','"
				+ systemuser.getCountry() + "','"
				+ new BigInteger(systemuser.getZipcode()) + "','"
				+ systemuser.getDrivinglicense() + "','"
				+ Date.valueOf(systemuser.getLicenseexpiry()) + "','"
				+ systemuser.getIssuingcountry() + "','"
				+ systemuser.getAACMember() + "','"
				+ systemuser.getEmail() + "','"
				+ systemuser.getDateofbirth() + "','"
				+ new BigInteger(systemuser.getContact()) + "')";
		try {   
		conn = dbconnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = (Statement) conn.createStatement();
		stmt.executeUpdate(insertSystemUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} finally {
		try {
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		};
	}
	}
	
	public static void UpdateAdmin(SystemUser systemuser) {

		Connection conn = dbconnection.getDBConnection();  
		PreparedStatement ps=null;

		String insertSystemUser = "UPDATE registration SET username = ?,password=?,role=?,UTAID=?,firstname=?, lastname=?,"
				+"addressline1=?,addressline2=?,city=?,state=?,country=?,zipcode=?,drivinglicense=?,licenseexpiry=?,"
				+"issuingcountry=?,AACmember=?,email=?,dateofbirth=?,contact=? WHERE username = ?";					

		try {   
		conn = dbconnection.getDBConnection();  
		conn.setAutoCommit(false);   
		ps=conn.prepareStatement(insertSystemUser);
		ps.setString(1, systemuser.getUsername());
		ps.setString(2, systemuser.getPassword());

		ps.setString(3, systemuser.getRole());
		ps.setString(4, systemuser.getUTAID());
		ps.setString(5, systemuser.getFirstname());
		ps.setString(6, systemuser.getLastname());
		ps.setString(7, systemuser.getAddressline1());
		ps.setString(8, systemuser.getAddressline2());
		ps.setString(9, systemuser.getCity());
		ps.setString(10, systemuser.getState());
		ps.setString(11, systemuser.getCountry());
		ps.setString(12, systemuser.getZipcode());
		ps.setString(13, systemuser.getDrivinglicense());
		ps.setString(14, systemuser.getLicenseexpiry());
		ps.setString(15, systemuser.getIssuingcountry());
		ps.setString(16, systemuser.getAACMember());
		ps.setString(17, systemuser.getEmail());
		ps.setString(18, systemuser.getDateofbirth());
		ps.setString(19, systemuser.getContact());
		ps.setString(20, systemuser.getUsername());
	
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();

		
	}
		
	}
	
	public static boolean uniqueUsername(String username2) {
		Statement stmt = null;   
		Connection conn = null; 
		try {
			conn = dbconnection.getDBConnection();  
			stmt = (Statement) conn.createStatement();
			String searchSystemUser = " SELECT * from registration WHERE username = '"+username2+"'";
			ResultSet systemUserList = stmt.executeQuery(searchSystemUser);
			while (systemUserList.next()) {
				SystemUser systemUser = new SystemUser(); 
				String username = systemUserList.getString("username");
				String password  = systemUserList.getString("password");
				String role  = systemUserList.getString("role");
				String utaid  = systemUserList.getString("UTAID");		
				String firstname  = systemUserList.getString("role");
				String lastname  = systemUserList.getString("role");
				String addressline1  = systemUserList.getString("role");
				String addressline2  = systemUserList.getString("role");	
				String city  = systemUserList.getString("role");
				String state  = systemUserList.getString("role");
				String country  = systemUserList.getString("role");
				String zipcode  = systemUserList.getString("zipcode");
				String drivingLicense  = systemUserList.getString("drivinglicense");
				//SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
				String licenseExpiry = systemUserList.getString("licenseexpiry");
				String issuingCountry  = systemUserList.getString("issuingcountry");
				String aacMember  = systemUserList.getString("AACmember");
				String email  = systemUserList.getString("email");
				String dateOfBirth = systemUserList.getString("dateofbirth");
				String contact  = systemUserList.getString("contact");

				systemUser.setUsername(username);  
				systemUser.setPassword(password);
				systemUser.setRole(role);
				systemUser.setUTAID(utaid.toString());
				systemUser.setFirstname(firstname);
				systemUser.setLastname(lastname);
				systemUser.setAddressline1(addressline1);
				systemUser.setAddressline2(addressline2);
				systemUser.setCity(city);
				systemUser.setState(state);
				systemUser.setCountry(country);
				systemUser.setZipcode(zipcode);
				systemUser.setDrivinglicense(drivingLicense);
				systemUser.setLicenseexpiry(licenseExpiry);
				systemUser.setIssuingcountry(issuingCountry);
				systemUser.setAACMember(aacMember);
				systemUser.setEmail(email);
				systemUser.setDateofbirth(dateOfBirth);
				systemUser.setContact(contact);
			} 
			return (systemUserList.last());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return false;
	}

	public static boolean checkIfAACMember(String username) {
		boolean isMember = false;
		Statement stmt = null;   
		Connection conn = null;  
		try {   
			conn = dbconnection.getDBConnection();  
			stmt = (Statement) conn.createStatement();
			String checkIfAACMember = " SELECT AACmember from registration WHERE username = '"+username+"'";
			ResultSet member = stmt.executeQuery(checkIfAACMember);
			
			while(member.next()) {
				if(member.getString(1).equalsIgnoreCase("Yes")) {
					isMember = true;
				}
			}
	}
		catch(Exception e) {
			System.out.println(e);
		}
		return isMember;
	}


	public ArrayList<BookedReservations> viewMyRentals(String username) {
		Statement stmt = null;   
		Connection conn = null;  
		ArrayList<BookedReservations> br = new ArrayList<BookedReservations>();
		try {   
			conn = dbconnection.getDBConnection();  
			stmt = (Statement) conn.createStatement();
			String query = " SELECT * from reservations WHERE username = '"+username+"'";
			ResultSet reservations = stmt.executeQuery(query);
			
			while(reservations.next()) {
				BookedReservations bc = new BookedReservations();
				bc.setReservationID(reservations.getInt(1));
				bc.setUsername(reservations.getString(2));
				bc.setCarSelected(reservations.getString(3));
				bc.setNoOfOccupants(reservations.getInt(4));
				bc.setStartDate(reservations.getDate(5).toString());
				bc.setEndDate(reservations.getDate(6).toString());
				bc.setStartTime(reservations.getTime(7).toString());
				bc.setEndTime(reservations.getTime(8).toString());
				bc.setGps(reservations.getString(9));
				bc.setOnstar(reservations.getString(10));
				bc.setSiriusxm(reservations.getString(11));
				bc.setCost(reservations.getDouble(12));
				br.add(bc);	
			}
	}
		catch(Exception e) {
			System.out.println(e);
		}
		return br;
		
	}


	public boolean checkRevoked(String username) {
		Statement stmt = null;   
		Connection conn = null;  
		boolean isRevoked = false;
		try {   
			conn = dbconnection.getDBConnection();  
			stmt = (Statement) conn.createStatement();
			String query = " SELECT * from revoked WHERE username = '"+username+"'";
			ResultSet revoked = stmt.executeQuery(query);
			
			if(revoked.first()) {
				isRevoked = true;
				}
			}
			catch (Exception e){
				System.out.println(e);
			}
		System.out.println(isRevoked);	
		return isRevoked;
	}


	public static void UpdateUser(SystemUser systemuser) {
 
		Connection conn = dbconnection.getDBConnection();  
		PreparedStatement ps=null;
		String insertSystemUser = "UPDATE registration SET username = ?,password=?,role=?,UTAID=?,firstname=?, lastname=?,"
				+"addressline1=?,addressline2=?,city=?,state=?,country=?,zipcode=?,drivinglicense=?,licenseexpiry=?,"
				+"issuingcountry=?,AACmember=?,email=?,dateofbirth=?,contact=? WHERE username = ?";					

		try {   
		conn = dbconnection.getDBConnection();  
		conn.setAutoCommit(false);   
		ps=conn.prepareStatement(insertSystemUser);
		ps.setString(1, systemuser.getUsername());
		ps.setString(2, systemuser.getPassword());

		ps.setString(3, systemuser.getRole());
		ps.setString(4, systemuser.getUTAID());
		ps.setString(5, systemuser.getFirstname());
		ps.setString(6, systemuser.getLastname());
		ps.setString(7, systemuser.getAddressline1());
		ps.setString(8, systemuser.getAddressline2());
		ps.setString(9, systemuser.getCity());
		ps.setString(10, systemuser.getState());
		ps.setString(11, systemuser.getCountry());
		ps.setString(12, systemuser.getZipcode());
		ps.setString(13, systemuser.getDrivinglicense());
		ps.setString(14, systemuser.getLicenseexpiry());
		ps.setString(15, systemuser.getIssuingcountry());
		ps.setString(16, systemuser.getAACMember());
		ps.setString(17, systemuser.getEmail());
		ps.setString(18, systemuser.getDateofbirth());
		ps.setString(19, systemuser.getContact());
		ps.setString(20, systemuser.getUsername());
		ps.executeUpdate();
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
		
	}
		
	}
	
	public static void UpdateSystemUser(SystemUser systemuser) {

 
		Connection conn = dbconnection.getDBConnection();  
		PreparedStatement ps=null;

		String insertSystemUser = "UPDATE registration SET username = ?,role=?,UTAID=?,firstname=?, lastname=?,"
				+"addressline1=?,addressline2=?,city=?,state=?,country=?,zipcode=?,drivinglicense=?,licenseexpiry=?,"
				+"issuingcountry=?,AACmember=?,email=?,dateofbirth=?,contact=? WHERE username = ?";					
//		insertSystemUser += " VALUES ('"  
//				+ systemuser.getUsername()  + "','"
//				+ systemuser.getPassword() + "','"
//				+ systemuser.getRole() + "','"		
//				+ new BigInteger(systemuser.getUTAID()) + "','"
//				+ systemuser.getFirstname() + "','" 
//				+ systemuser.getLastname() + "','"
//				+ systemuser.getAddressline1() + "','"
//				+ systemuser.getAddressline2() + "','"
//				+ systemuser.getCity() + "','"
//				+ systemuser.getState() + "','"
//				+ systemuser.getCountry() + "','"
//				+ new BigInteger(systemuser.getZipcode()) + "','"
//				+ systemuser.getDrivinglicense() + "','"
//				+ Date.valueOf(systemuser.getLicenseexpiry()) + "','"
//				+ systemuser.getIssuingcountry() + "','"
//				+ systemuser.getAACMember() + "','"
//				+ systemuser.getEmail() + "','"
//				+ systemuser.getDateofbirth() + "','"
//				+ new BigInteger(systemuser.getContact()) + "')";
		try {   
		conn = dbconnection.getDBConnection();  
		conn.setAutoCommit(false);   
		ps=conn.prepareStatement(insertSystemUser);
		ps.setString(1, systemuser.getUsername());
		ps.setString(2, systemuser.getRole());
		ps.setString(3, systemuser.getUTAID());
		ps.setString(4, systemuser.getFirstname());
		ps.setString(5, systemuser.getLastname());
		ps.setString(6, systemuser.getAddressline1());
		ps.setString(7, systemuser.getAddressline2());
		ps.setString(8, systemuser.getCity());
		ps.setString(9, systemuser.getState());
		ps.setString(10, systemuser.getCountry());
		ps.setString(11, systemuser.getZipcode());
		ps.setString(12, systemuser.getDrivinglicense());
		ps.setString(13, systemuser.getLicenseexpiry());
		ps.setString(14, systemuser.getIssuingcountry());
		ps.setString(15, systemuser.getAACMember());
		ps.setString(16, systemuser.getEmail());
		ps.setString(17, systemuser.getDateofbirth());
		ps.setString(18, systemuser.getContact());
		ps.setString(19, systemuser.getUsername());


//		ps.setDate(2, edate);
//		ps.setDate(3, sdate);
//		ps.setDate(4, edate);

//		stmt = (Statement) conn.createStatement();
//		ps=conn.prepareStatement(query);
//		stmt.setString(1, systemuser.getUsername());
		
//		rs=ps.executeQuery();
		
//		stmt.executeUpdate(insertSystemUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
//	} finally {
//		try {
//			conn.close();
//			stmt.close();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}
		
	}
}
		
}

